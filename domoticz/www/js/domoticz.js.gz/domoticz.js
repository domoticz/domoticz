/*
 Domoticz JS v1.0.1 (2012-12-27)

 (c) 2012-2013 Domoticz.com
*/
jQuery.fn.center = function(parent) {
    if (parent) {
        parent = this.parent();
    } else {
        parent = window;
    }
    this.css({
        "position": "absolute",
        "top": ((($(parent).height() - this.outerHeight()) / 2) + $(parent).scrollTop() + "px"),
        "left": ((($(parent).width() - this.outerWidth()) / 2) + $(parent).scrollLeft() + "px")
    });
	return this;
};

/* Get the rows which are currently selected */
function fnGetSelected( oTableLocal )
{
    return oTableLocal.$('tr.row_selected');
}

function GetBackbuttonHTMLTable(backfunction)
{
  var xhtm=
        '\t<table class="bannav" id="bannav" border="0" cellpadding="0" cellspacing="0" width="100%">\n' +
        '\t<tr>\n' +
        '\t  <td>\n' +
        '\t    <a class="btnstylerev" onclick="' + backfunction + '()" data-i18n="Back">Back</a>\n' +
        '\t  </td>\n' +
        '\t</tr>\n' +
        '\t</table>\n' +
        '\t<br>\n';
  return xhtm;
}

function GetBackbuttonHTMLTableWithRight(backfunction,rightfunction,rightlabel)
{
  var xhtm=
        '\t<table class="bannav" id="bannav" border="0" cellpadding="0" cellspacing="0" width="100%">\n' +
        '\t<tr>\n' +
        '\t  <td align="left">\n' +
        '\t    <a class="btnstylerev" onclick="' + backfunction + '()" data-i18n="Back">Back</a>\n' +
        '\t  </td>\n' +
        '\t  <td align="right">\n' +
        '\t    <a class="btnstyle" onclick="' + rightfunction + '" data-i18n="'+rightlabel+'">'+rightlabel+'</a>\n' +
        '\t  </td>\n' +
        '\t</tr>\n' +
        '\t</table>\n' +
        '\t<br>\n';
  return xhtm;
}

function GetBackbuttonTransferHTMLTable(backfunction, id)
{
  var xhtm=
        '\t<table class="bannav" id="bannav" border="0" cellpadding="0" cellspacing="0" width="100%">\n' +
        '\t<tr>\n' +
        '\t  <td align="left">\n' +
        '\t    <a class="btnstylerev" onclick="' + backfunction + '()" data-i18n="Back">Back</a>\n' +
        '\t  </td>\n' +
        '\t  <td align="right">\n' +
        '\t    <a class="btnstyle" onclick="TransferSensor(' + id + ')" data-i18n="Transfer">Transfer</a>\n' +
        '\t  </td>\n' +
        '\t</tr>\n' +
        '\t</table>\n' +
        '\t<br>\n';
  return xhtm;
}

function isiPhone(){
    return (
        //Detect iPhone
        (navigator.platform.indexOf("iPhone") != -1) ||
        //Detect iPod
        (navigator.platform.indexOf("iPod") != -1)
    );
}

function ArmSystem(idx,switchcmd, refreshfunction)
{
	if (window.my_config.userrights==0) {
        HideNotify();
		ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
		return;
	}
	clearInterval($.myglobals.refreshTimer);

	$.devIdx=idx;

   var $dialog = $('<div>How would you like to Arm the System?</div>').dialog({
			modal: true,
			width: 340,
			resizable: false,
			draggable: false,
            buttons: [
                  {
                        text: $.i18n("Arm Home"),
                        click: function(){
							$dialog.remove();
							switchcmd="Arm Home";
							ShowNotify($.i18n('Switching') + ' ' + $.i18n(switchcmd));
							$.ajax({
							 url: "json.htm?type=command&param=switchlight&idx=" + $.devIdx + "&switchcmd=" + switchcmd + "&level=0",
							 async: false, 
							 dataType: 'json',
							 success: function(data) {
							  //wait 1 second
							  setTimeout(function() {
								HideNotify();
								refreshfunction();
							  }, 1000);
							 },
							 error: function(){
								HideNotify();
								alert($.i18n('Problem sending switch command'));
							 }     
							});
                        }
                  },
                  {
                        text: $.i18n("Arm Away"),
                        click: function(){
							$dialog.remove();
							switchcmd="Arm Away";
							ShowNotify($.i18n('Switching') + ' ' + $.i18n(switchcmd));
							$.ajax({
							 url: "json.htm?type=command&param=switchlight&idx=" + $.devIdx + "&switchcmd=" + switchcmd + "&level=0",
							 async: false, 
							 dataType: 'json',
							 success: function(data) {
							  //wait 1 second
							  setTimeout(function() {
								HideNotify();
								refreshfunction();
							  }, 1000);
							 },
							 error: function(){
								HideNotify();
								alert($.i18n('Problem sending switch command'));
							 }     
							});
                        }
                  }
            ]
      });
}

function SwitchLight(idx,switchcmd, refreshfunction)
{
	if (window.my_config.userrights==0) {
        HideNotify();
		ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
		return;
	}
  clearInterval($.myglobals.refreshTimer);
  ShowNotify($.i18n('Switching') + ' ' + $.i18n(switchcmd));
 
  $.ajax({
     url: "json.htm?type=command&param=switchlight&idx=" + idx + "&switchcmd=" + switchcmd + "&level=0",
     async: false, 
     dataType: 'json',
     success: function(data) {
      //wait 1 second
      setTimeout(function() {
        HideNotify();
        refreshfunction();
      }, 1000);
     },
     error: function(){
        HideNotify();
        alert($.i18n('Problem sending switch command'));
     }     
  });
}

function SwitchScene(idx,switchcmd, refreshfunction)
{
	if (window.my_config.userrights==0) {
        HideNotify();
		ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
		return;
	}

  clearInterval($.myglobals.refreshTimer);
  ShowNotify($.i18n('Switching') + ' ' + $.i18n(switchcmd));
 
  $.ajax({
     url: "json.htm?type=command&param=switchscene&idx=" + idx + "&switchcmd=" + switchcmd,
     async: false, 
     dataType: 'json',
     success: function(data) {
      //wait 1 second
      setTimeout(function() {
        HideNotify();
        refreshfunction();
      }, 1000);
     },
     error: function(){
        HideNotify();
        alert($.i18n('Problem sending switch command'));
     }     
  });
}

function ResetSecurityStatus(idx,switchcmd, refreshfunction)
{
	if (window.my_config.userrights==0) {
        HideNotify();
		ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
		return;
	}

  clearInterval($.myglobals.refreshTimer);
  ShowNotify($.i18n('Switching') + ' ' + $.i18n(switchcmd));
 
  $.ajax({
     url: "json.htm?type=command&param=resetsecuritystatus&idx=" + idx + "&switchcmd=" + switchcmd,
     async: false, 
     dataType: 'json',
     success: function(data) {
      //wait 1 second
      setTimeout(function() {
        HideNotify();
        refreshfunction();
      }, 1000);
     },
     error: function(){
        HideNotify();
        alert($.i18n('Problem sending switch command'));
     }     
  });
}

function RefreshLightLogTable(idx)
{
	var mTable = $($.content + ' #lighttable');
	var oTable = mTable.dataTable();
	oTable.fnClearTable();
  
	$.ajax({
		url: "json.htm?type=lightlog&idx=" + idx, 
		async: false, 
		dataType: 'json',
		success: function(data) {
			if (typeof data.result != 'undefined') {
				var datatable = [];
				var chart=$.LogChart.highcharts();
				var ii=0;
				$.each(data.result, function(i,item){
					var addId = oTable.fnAddData([
						  item.Date,
						  item.Data
						],false);
					var level=-1;
					if (item.Data.indexOf('Off') >= 0) {
						level=0;
					}
					else if (item.Data.indexOf('Set Level:') == 0) {
						var lstr=item.Data.substr(11);
						var idx=lstr.indexOf('%');
						if (idx!=-1) {
							lstr=lstr.substr(0,idx-1);
							level=parseInt(lstr);
						}
					}
					else {
						var idx=item.Data.indexOf('Level: ');
						if (idx!=-1)
						{
							var lstr=item.Data.substr(idx+7);
							var idx=lstr.indexOf('%');
							if (idx!=-1) {
								lstr=lstr.substr(0,idx-1);
								level=parseInt(lstr);
								if (level>100) {
									level=100;
								}
							}
						}
						else {
							if ((item.Data.indexOf('On') == 0)||(item.Data.indexOf('Group On') == 0)||(item.Data.indexOf('Open inline relay') == 0)) {
								level=100;
							}
						}
					}
					if (level!=-1) {
						datatable.unshift( [GetUTCFromStringSec(item.Date), level ] );
					}
				});
				mTable.fnDraw();
				chart.series[0].setData(datatable);
			}
		}
	});
}

function ClearLightLog()
{
	if (window.my_config.userrights!=2) {
        HideNotify();
		ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
		return;
	}
	var bValid = false;
	bValid=(confirm($.i18n("Are you sure to delete the Log?\n\nThis action can not be undone!"))==true);
	if (bValid == false)
		return;
	$.ajax({
		 url: "json.htm?type=command&param=clearlightlog&idx=" + $.devIdx,
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
				RefreshLightLogTable($.devIdx);
		 },
		 error: function(){
				HideNotify();
				ShowNotify($.i18n('Problem clearing the Log!'), 2500, true);
		 }     
	});
}

function ShowLightLog(id,name,content,backfunction)
{
	clearInterval($.myglobals.refreshTimer);
	$.content=content;

	$.devIdx=id;

	$('#modal').show();
	var htmlcontent = '';
	htmlcontent='<p><h2><span data-i18n="Name"></span>: ' + name + '</h2></p>\n';
	htmlcontent+=$('#lightlog').html();
	$($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
	$($.content).i18n();
	$.LogChart = $($.content + ' #lightgraph');
	$.LogChart.highcharts({
		chart: {
		  type: 'line',
		  zoomType: 'xy',
		  marginRight: 10
		},
		credits: {
		  enabled: true,
		  href: "http://www.domoticz.com",
		  text: "Domoticz.com"
		},
		title: {
			text: null
		},
		xAxis: {
			type: 'datetime'
		},
		yAxis: {
			title: {
				text: $.i18n('Percentage') +' (%)'
			},
			endOnTick: false,
			startOnTick: false
		},
		tooltip: {
			formatter: function() {
					return ''+
					Highcharts.dateFormat('%A<br/>%Y-%m-%d %H:%M:%S', this.x) +': '+ this.y +' %';
			}
		},
		plotOptions: {
			line: {
				lineWidth: 3,
				states: {
					hover: {
						lineWidth: 3
					}
				},
				marker: {
					enabled: false,
					states: {
						hover: {
							enabled: true,
							symbol: 'circle',
							radius: 5,
							lineWidth: 1
						}
					}
				}
			}
		},
		series: [{
			showInLegend: false,
			name: 'percent',
			step: 'left'
		}]
		,
		navigation: {
			menuItemStyle: {
				fontSize: '10px'
			}
		}
	});
  
  var oTable = $($.content + ' #lighttable').dataTable( {
                  "sDom": '<"H"lfrC>t<"F"ip>',
                  "oTableTools": {
                    "sRowSelect": "single",
                  },
                  "aaSorting": [[ 0, "desc" ]],
                  "bSortClasses": false,
                  "bProcessing": true,
                  "bStateSave": true,
                  "bJQueryUI": true,
                  "aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
                  "iDisplayLength" : 25,
                  "sPaginationType": "full_numbers"
                } );

	RefreshLightLogTable($.devIdx);
  $('#modal').hide();
  return false;
}

function GetNotificationSettings()
{
	var nsettings = {};

	nsettings.type=$($.content + " #notificationparamstable #combotype").val();
	var whenvisible=$($.content + " #notificationparamstable #notiwhen").is(":visible");
	if (whenvisible==false) {
		nsettings.when=0;
		nsettings.value=0;
	}
	else {
		nsettings.when=$($.content + " #notificationparamstable #combowhen").val();
		nsettings.value=$($.content + " #notificationparamstable #value").val();
		if ((nsettings.value=="")||(isNaN(nsettings.value)))
		{
			ShowNotify($.i18n('Please correct the Value!'), 2500, true);
			return null;
		}
	}
	nsettings.priority=$($.content + " #notificationparamstable #combopriority").val();
  if ((nsettings.priority=="")||(isNaN(nsettings.priority)))
	{
		ShowNotify($.i18n('Please select a Priority level!'), 2500, true);
		return null;
	}
	return nsettings;
}

function ClearNotifications()
{
	var bValid = false;
	bValid=(confirm($.i18n("Are you sure to delete ALL notifications?\n\nThis action can not be undone!!"))==true);
	if (bValid == false)
		return;

	$.ajax({
		 url: "json.htm?type=command&param=clearnotifications&idx=" + $.devIdx,
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
			RefreshNotificationTable($.devIdx);
		 },
		 error: function(){
				HideNotify();
				ShowNotify($.i18n('Problem clearing notifications!'), 2500, true);
		 }     
	});
}

function UpdateNotification(idx)
{
	var nsettings=GetNotificationSettings();
	if (nsettings==null) {
		return;
	}
	$.ajax({
		 url: "json.htm?type=command&param=updatenotification&idx=" + idx + 
					"&devidx=" + $.devIdx +
					"&ttype=" + nsettings.type +
					"&twhen=" + nsettings.when +
					"&tvalue=" + nsettings.value +
					"&tpriority=" + nsettings.priority,
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
			RefreshNotificationTable($.devIdx);
		 },
		 error: function(){
				HideNotify();
				ShowNotify($.i18n('Problem updating notification!'), 2500, true);
		 }     
	});
}

function DeleteNotification(idx)
{
	var bValid = false;
	bValid=(confirm($.i18n("Are you sure to delete this notification?\n\nThis action can not be undone..."))==true);
	if (bValid == false)
		return;
		
	$.ajax({
		 url: "json.htm?type=command&param=deletenotification&idx=" + idx,
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
			RefreshNotificationTable($.devIdx);
		 },
		 error: function(){
				HideNotify();
				ShowNotify($.i18n('Problem deleting notification!'), 2500, true);
		 }     
	});
}

function AddNotification()
{
	var nsettings=GetNotificationSettings();
	if (nsettings==null)
	{
	alert($.i18n("Invalid Notification Settings"));
		return;
	}
	$.ajax({
		url: "json.htm?type=command&param=addnotification&idx=" + $.devIdx + 
				"&ttype=" + nsettings.type +
				"&twhen=" + nsettings.when +
				"&tvalue=" + nsettings.value +
				"&tpriority=" + nsettings.priority,
		async: false, 
		dataType: 'json',
		success: function(data) {
			if (data.status != "OK") {
				HideNotify();
				ShowNotify($.i18n('Problem adding notification!<br>Duplicate Value?'), 2500, true);
				return;
			}
			RefreshNotificationTable($.devIdx);
		},
		error: function(){
			HideNotify();
			ShowNotify($.i18n('Problem adding notification!'), 2500, true);
		}     
	});
}

function RefreshNotificationTable(idx)
{
  $('#modal').show();

	$($.content + ' #updelclr #notificationupdate').attr("class", "btnstyle3-dis");
	$($.content + ' #updelclr #notificationdelete').attr("class", "btnstyle3-dis");

  var oTable = $($.content + ' #notificationtable').dataTable();
  oTable.fnClearTable();
  
  $.ajax({
     url: "json.htm?type=notifications&idx=" + idx, 
     async: false, 
     dataType: 'json',
     success: function(data) {
      if (typeof data.result != 'undefined') {
        $.each(data.result, function(i,item){
			var parts = item.Params.split(';');
			var nvalue=0;
			if (parts.length>1) {
				nvalue=parts[2];
			}
			var whenstr = "";
			
			var ntype="";
			var stype="";
			if (parts[0]=="T")
			{
				ntype=$.i18n("Temperature");
				stype=" &deg; C";
			}
			else if (parts[0]=="D")
			{
				ntype=$.i18n("Dew Point");
				stype=" &deg; C";
			}
			else if (parts[0]=="H")
			{
				ntype=$.i18n("Humidity");
				stype=" %";
			}
			else if (parts[0]=="R")
			{
				ntype=$.i18n("Rain");
				stype=" mm";
			}
			else if (parts[0]=="W")
			{
				ntype=$.i18n("Wind");
				stype=" " + $.myglobals.windsign;
			}
			else if (parts[0]=="U")
			{
				ntype=$.i18n("UV");
				stype=" UVI";
			}
			else if (parts[0]=="M")
			{
				ntype=$.i18n("Usage");
			}
			else if (parts[0]=="B")
			{
				ntype=$.i18n("Baro");
				stype=" hPa";
			}
			else if (parts[0]=="S")
			{
				ntype=$.i18n("Switch On");
			}
			else if (parts[0]=="O")
			{
				ntype=$.i18n("Switch Off");
			}
			else if (parts[0]=="E")
			{
				ntype=$.i18n("Today");
				stype=" kWh";
			}
			else if (parts[0]=="G")
			{
				ntype=$.i18n("Today");
				stype=" m3";
			}
			else if (parts[0]=="1")
			{
				ntype=$.i18n("Ampere 1");
				stype=" A";
			}
			else if (parts[0]=="2")
			{
				ntype=$.i18n("Ampere 2");
				stype=" A";
			}
			else if (parts[0]=="3")
			{
				ntype=$.i18n("Ampere 3");
				stype=" A";
			}
			else if (parts[0]=="P")
			{
				ntype=$.i18n("Percentage");
				stype=" %";
			}

			var nwhen="";
			if (ntype==$.i18n("Switch On")) {
				whenstr=$.i18n("On");
			}
			else if (ntype==$.i18n("Switch Off")) {
				whenstr=$.i18n("Off");
			}
			else if (ntype==$.i18n("Dew Point")) {
				whenstr=$.i18n("Dew Point");
			}
			else {
				if (parts[1]==">") {
					nwhen=$.i18n("Greater") + " ";
				}
				else {
					nwhen=$.i18n("Below") + " ";
				}
				whenstr= nwhen + nvalue + stype;
			}
			var priorityStr="";
			if (item.Priority==-2) {
        priorityStr=$.i18n("Very Low");
			}	
			else if (item.Priority==-1) {
        priorityStr=$.i18n("Moderate");
			}
			else if (item.Priority==0) {
        priorityStr=$.i18n("Normal");
			}
			else if (item.Priority==1) {
        priorityStr=$.i18n("High");
			}
			else if (item.Priority==2) {
        priorityStr=$.i18n("Emergency");
			}
			var addId = oTable.fnAddData( {
				"DT_RowId": item.idx,
				"nvalue" : nvalue,
				"Priority": item.Priority,
				"0": ntype,
				"1": whenstr,
				"2": priorityStr
			} );
		});
		/* Add a click handler to the rows - this could be used as a callback */
		$($.content + " #notificationtable tbody tr").click( function( e ) {
			if ( $(this).hasClass('row_selected') ) {
				$(this).removeClass('row_selected');
				$($.content + ' #updelclr #notificationupdate').attr("class", "btnstyle3-dis");
				$($.content + ' #updelclr #notificationdelete').attr("class", "btnstyle3-dis");
			}
			else {
				oTable.$('tr.row_selected').removeClass('row_selected');
				$(this).addClass('row_selected');
				$($.content + ' #updelclr #notificationupdate').attr("class", "btnstyle3");
				$($.content + ' #updelclr #notificationdelete').attr("class", "btnstyle3");
				var anSelected = fnGetSelected( oTable );
				if ( anSelected.length !== 0 ) {
					var data = oTable.fnGetData( anSelected[0] );
					var idx= data["DT_RowId"];
					$.myglobals.SelectedNotificationIdx=idx;
					$($.content + " #updelclr #notificationupdate").attr("href", "javascript:UpdateNotification(" + idx + ")");
					$($.content + " #updelclr #notificationdelete").attr("href", "javascript:DeleteNotification(" + idx + ")");
					//update user interface with the paramters of this row
					$($.content + " #notificationparamstable #combotype").val(GetValTextInNTypeStrArray(data["0"]));
					ShowNotificationTypeLabel();
					var matchstr="^" + $.i18n("Greater");
					if (data["1"].match(matchstr)) {
						$($.content + " #notificationparamstable #combowhen").val(0);
					}
					else {
						$($.content + " #notificationparamstable #combowhen").val(1);
					}
					$($.content + " #notificationparamstable #value").val(data["nvalue"]);
					$($.content + " #notificationparamstable #combopriority").val(data["Priority"]);
				}
			}
		}); 
      }
     }
  });
  $('#modal').hide();
}

function ShowNotificationTypeLabel()
{
	var typetext = $($.content + " #notificationparamstable #combotype option:selected").text();
	
	if (
		(typetext == $.i18n("Switch On"))||
		(typetext == $.i18n("Switch Off"))||
		(typetext == $.i18n("Dew Point"))
		) {
		$($.content + " #notificationparamstable #notiwhen").hide();
		$($.content + " #notificationparamstable #notival").hide();
		return;
	}
	$($.content + " #notificationparamstable #notiwhen").show();
	$($.content + " #notificationparamstable #notival").show();
	
	if (typetext == $.i18n('Temperature'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;&deg; C');
	else if (typetext == $.i18n('Dew Point'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;&deg; C');
	else if (typetext == $.i18n('Humidity'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;%');
	else if (typetext == $.i18n('UV'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;UVI');
	else if (typetext == $.i18n('Rain'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;mm');
	else if (typetext == $.i18n('Wind'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;' + $.myglobals.windsign);
	else if (typetext == $.i18n('Baro'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;hPa');
	else if (typetext == $.i18n('Usage'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;');
	else if (typetext == $.i18n('Today'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;');
	else if (typetext == $.i18n('Total'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;');
	else if (typetext == $.i18n('Ampere 1'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;A');
	else if (typetext == $.i18n('Ampere 2'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;A');
	else if (typetext == $.i18n('Ampere 3'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;A');
	else if (typetext == $.i18n('Percentage'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;%');
	else if (typetext == $.i18n('RPM'))
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;RPM');
	else
		$($.content + " #notificationparamstable #valuetype").html('&nbsp;??');
}

function GetValTextInNTypeStrArray(stext)
{
	var pos=-1;
	$.each($.NTypeStr, function(i,item){
		if ($.i18n(item.text) == stext)
		{
			pos = item.val;
		}
	});

	return pos;
}

function ShowNotifications(id,name,content,backfunction)
{
  clearInterval($.myglobals.refreshTimer);
  $.devIdx=id;
  $.content=content;
  
  $.NTypeStr = [];

	$.ajax({
		 url: "json.htm?type=command&param=getnotificationtypes&idx=" + $.devIdx,
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
		 
				if (typeof data.result != 'undefined') {
					$.each(data.result, function(i,item){
						$.NTypeStr.push({
							val: item.val,
							text: item.text,
							tag: item.ptag
						 }
						);
					});
				}
				
				var oTable;
				
				$('#modal').show();
				var htmlcontent = '';
				htmlcontent='<p><h2><span data-i18n="Name"></span>: ' + name + '</h2></p><br>\n';
				htmlcontent+=$('#editnotifications').html();
				$($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
				$($.content).i18n();
				
				//add types to combobox
				$.each($.NTypeStr, function(i,item){
					var option = $('<option />');
					option.attr('value', item.val).text($.i18n(item.text));
					$($.content + ' #notificationparamstable #combotype').append(option);
				});
				
				oTable = $($.content + ' #notificationtable').dataTable( {
												"sDom": '<"H"lfrC>t<"F"ip>',
												"oTableTools": {
													"sRowSelect": "single",
												},
												"aaSorting": [[ 0, "desc" ]],
												"bSortClasses": false,
												"bProcessing": true,
												"bStateSave": true,
												"bJQueryUI": true,
												"aLengthMenu": [[25, 50, 100, -1], [25, 50, 100, "All"]],
												"iDisplayLength" : 25,
												"sPaginationType": "full_numbers"
											} );

				$($.content + " #notificationparamstable #combotype").change(function() {
					ShowNotificationTypeLabel();
				});
			 
				ShowNotificationTypeLabel();
				$('#modal').hide();
				RefreshNotificationTable(id);
		 },
		 error: function(){
				HideNotify();
				ShowNotify($.i18n('Problem clearing notifications!'), 2500, true);
		 }     
	});
}

function GetUTCFromString(s)
{
    return Date.UTC(
      parseInt(s.substring(0, 4), 10),
      parseInt(s.substring(5, 7), 10) - 1,
      parseInt(s.substring(8, 10), 10),
      parseInt(s.substring(11, 13), 10),
      parseInt(s.substring(14, 16), 10),
      0
    );
}

function GetUTCFromStringSec(s)
{
    return Date.UTC(
      parseInt(s.substring(0, 4), 10),
      parseInt(s.substring(5, 7), 10) - 1,
      parseInt(s.substring(8, 10), 10),
      parseInt(s.substring(11, 13), 10),
      parseInt(s.substring(14, 16), 10),
      parseInt(s.substring(17, 19), 10)
    );
}

function GetDateFromString(s)
{
    return Date.UTC(
      parseInt(s.substring(0, 4), 10),
      parseInt(s.substring(5, 7), 10) - 1,
      parseInt(s.substring(8, 10), 10));
}

function cursorhand()
{
    document.body.style.cursor = "pointer";
}

function cursordefault()
{
   document.body.style.cursor = "default";
}
      
function ShowNotify(txt, timeout, iserror)
{
	$("#notification").html('<p>' + txt + '</p>');
	
	if (typeof iserror != 'undefined') {
		$("#notification").css("background-color","red");
	} else {
		$("#notification").css("background-color","#204060");
	}
	$("#notification").center();
	$("#notification").fadeIn("slow");

	if (typeof timeout != 'undefined') {
		setTimeout(function() {
			HideNotify();
		}, timeout);
	}
}

function HideNotify()
{
	$("#notification").hide();
}

function ChangeClass(elemname, newclass)
{
	document.getElementById(elemname).setAttribute("class", newclass);
}

function GetLayoutFromURL()
{
	var page = window.location.hash.substr(1);
	return page!=""?page:'Dashboard';
}

function SetLayoutURL(name)
{
	window.location.hash = name;
}

function SwitchLayout(layout)
{
	if (layout=="Logout")
	{
		$.ajax({
		 url: "json.htm?type=command&param=dologout",
		 async: true, 
		 dataType: 'json',
		 success: function(data) {
			window.location = '/';
		 },
		 error: function(){
			window.location = '/';
		 }     
		});
		return;
	}
	else if (layout=="Restart") {
		var bValid = false;
		bValid=(confirm($.i18n("Are you sure to Restart the system?"))==true);
		if ( bValid ) {
			$.ajax({
			 url: "json.htm?type=command&param=system_reboot",
			 async: true, 
			 dataType: 'json',
			 success: function(data) {
			 },
			 error: function(){
			 }     
			});
			alert($.i18n("Restarting System (This could take some time...)"));
		}
		return;
	}
	else if (layout=="Shutdown") {
		var bValid = false;
		bValid=(confirm($.i18n("Are you sure to Shutdown the system?"))==true);
		if ( bValid ) {
			$.ajax({
			 url: "json.htm?type=command&param=system_shutdown",
			 async: true, 
			 dataType: 'json',
			 success: function(data) {
			 },
			 error: function(){
			 }     
			});
			alert($.i18n("The system is being Shutdown (This could take some time...)"));
		}
		return;
	}
	var fullLayout = layout;
	var hyphen = layout.indexOf('-');
	if( hyphen >= 0 ){
		layout = layout.substr(0, hyphen);
	}

	clearInterval($.myglobals.refreshTimer);
	$.myglobals.prevlayout = $.myglobals.layout;
	$.myglobals.actlayout = layout;
	$.myglobals.layoutFull = fullLayout;
	$.myglobals.layoutParameters = fullLayout.substr(hyphen+1);
	
	//update menu items
	$("ul.nav li").removeClass("current_page_item");
	$("ul.nav #m"+layout).addClass("current_page_item");

	var durl=layout.toLowerCase()+".html";
	if (layout == "LightSwitches") {
		durl='lights.html';
	}
	if (window.my_config.userrights!=2) {
		if ((durl=='setup.html')||(durl=='users.html')||(durl=='cam.html')||(durl=='events.html')||(durl=='hardware.html')||(durl=='devices.html')) {
			durl='dashboard.html';
		}
	}

	$.ajax({
	 url: "json.htm?type=command&param=getversion",
	 async: true, 
	 dataType: 'json',
	 success: function(data) {
		if (data.status == "OK") {
			$( "#appversion" ).text("V" + data.version);
		}
	 },
	 error: function(){
	 }     
	});
		
	//stop chaching these pages
	var dt = new Date();
	durl+='?sid='+dt.getTime();

	if(GetLayoutFromURL() != fullLayout) SetLayoutURL(fullLayout);
	
	$(".bannercontent").load(durl, function(response, status, xhr) {
		if (status == "error") {
			var msg = "Sorry but there was an error: ";
			$(".bannercontent").html(msg + xhr.status + " " + xhr.statusText);
		}
	});

$('.btn-navbar').addClass('collapsed');
$('.nav-collapse').removeClass('in').css('height', '0');	
}

function ShowNewBannerContent(content, backlink)
{
	if (typeof backlink == 'undefined') {
		//hide back button
	}
	else {
		//set back button
	}
	$(".bannercontent").slideUp('slow', function() {
		$(".bannercontent").html(content);
		$(".bannercontent").slideDown('slow');
	});      
}

function AddDevice(id)
{
	$( "#dialog-adddevice" ).dialog( "open" );
}

function ShowLog(id)
{
	ShowNewBannerContent("Hier komt de log");
}

function checkLength( o, min, max ) 
{
			if ( o.val().length > max || o.val().length < min ) {
					return false;
			} else {
					return true;
			}
}

function SetDimValue(idx, value)
{
	clearInterval($.setDimValue);

	if (window.my_config.userrights==0) {
        HideNotify();
		ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
		return;
	}

	$.ajax({
		 url: "json.htm?type=command&param=switchlight&idx=" + idx + "&switchcmd=Set%20Level&level=" + value,
		 async: false, 
		 dataType: 'json'
	});
}

//Some helper for browser detection
function matchua ( ua ) 
{
	ua = ua.toLowerCase();

	var match = /(chrome)[ \/]([\w.]+)/.exec( ua ) ||
		/(webkit)[ \/]([\w.]+)/.exec( ua ) ||
		/(opera)(?:.*version|)[ \/]([\w.]+)/.exec( ua ) ||
		/(msie) ([\w.]+)/.exec( ua ) ||
		ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec( ua ) ||
		[];

	return {
		browser: match[ 1 ] || "",
		version: match[ 2 ] || "0"
	};
}

function Get5MinuteHistoryDaysGraphTitle()
{
	if ($.FiveMinuteHistoryDays==1) {
		return $.i18n("Last") + " 24 " + $.i18n("Hours");
	}
	else if  ($.FiveMinuteHistoryDays==2) {
		return $.i18n("Last") + " 48 " + $.i18n("Hours");
	}
	return $.i18n("Last") + " " + $.FiveMinuteHistoryDays + " " + $.i18n("Days");
}

function GenerateCamFeedURL(address,port,username,password,videourl)
{
	var feedsrc="http://";
	if (username!="")
	{
		feedsrc+=username+":"+password+"@";
	}
	feedsrc+=address;
	if (port!=80) {
		feedsrc+=":"+port;
	}
	feedsrc+="/" + videourl;
	return feedsrc;
}

function GenerateCamImageURL(address,port,username,password,imageurl)
{
	var feedsrc="http://";
	if (username!="")
	{
		feedsrc+=username+":"+password+"@";
	}
	feedsrc+=address;
	if (port!=80) {
		feedsrc+=":"+port;
	}
	feedsrc+="/" + imageurl;
	return feedsrc;
}

function GetTemp48Item(temp)
{
	if (temp<=0) {
		return "ice.png";
	}
	if (temp<5) {
		return "temp-0-5.png";
	}
	if (temp<10) {
		return "temp-5-10.png";
	}
	if (temp<15) {
		return "temp-10-15.png";
	}
	if (temp<20) {
		return "temp-15-20.png";
	}
	if (temp<25) {
		return "temp-20-25.png";
	}
	if (temp<30) {
		return "temp-25-30.png";
	}
	return "temp-gt-30.png";
}

function generate_noty(ntype, ntext, ntimeout) {
	var n = noty({
		text: ntext,
		type: ntype,
		dismissQueue: true,
		timeout: ntimeout,
		layout: 'topRight',
		theme: 'defaultTheme'
	});
}

function rgb2hex(rgb) {
	if (  rgb.search("rgb") == -1 ) {
			return rgb;
	} else {
			rgb = rgb.match(/^rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*(\d+))?\)$/);
			function hex(x) {
					 return ("0" + parseInt(x).toString(16)).slice(-2);
			}
			return "#" + hex(rgb[1]) + hex(rgb[2]) + hex(rgb[3]);
	}
}

function chartPointClick(event, retChart) {
	if (event.shiftKey!=true) {
		return;
	}
	if (window.my_config.userrights!=2) {
        HideNotify();
		ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
		return;
	}
	var dateString=Highcharts.dateFormat('%Y-%m-%d', event.point.x);
	var bValid = false;
	bValid=(confirm($.i18n("Are you sure to remove this value at") + " ?:\n\nDate: " + dateString + " \nValue: " + event.point.y)==true);
	if (bValid == false) {
		return;
	}
	$.ajax({
		 url: "json.htm?type=command&param=deletedatapoint&idx=" + $.devIdx + "&date=" + dateString,
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
			if (data.status == "OK") {
				retChart($.devIdx,$.devName);
			}
			else {
				ShowNotify($.i18n('Problem deleting data point!'), 2500, true);
			}
		 },
		 error: function(){
			ShowNotify($.i18n('Problem deleting data point!'), 2500, true);
		 }     
	}); 	
}

function chartPointClickNew(event, isShort, retChart) {
	if (event.shiftKey!=true) {
		return;
	}
	if (window.my_config.userrights!=2) {
        HideNotify();
		ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
		return;
	}
	var dateString;
	if (isShort==false) {
		dateString=Highcharts.dateFormat('%Y-%m-%d', event.point.x);
	}
	else {
		dateString=Highcharts.dateFormat('%Y-%m-%d %H:%M:%S', event.point.x);
	}
	var bValid = false;
	bValid=(confirm($.i18n("Are you sure to remove this value at") + " ?:\n\nDate: " + dateString + " \nValue: " + event.point.y)==true);
	if (bValid == false) {
		return;
	}
	$.ajax({
		 url: "json.htm?type=command&param=deletedatapoint&idx=" + $.devIdx + "&date=" + dateString,
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
			if (data.status == "OK") {
				retChart($.content,$.backfunction,$.devIdx,$.devName);
			}
			else {
				ShowNotify($.i18n('Problem deleting data point!'), 2500, true);
			}
		 },
		 error: function(){
			ShowNotify($.i18n('Problem deleting data point!'), 2500, true);
		 }     
	}); 	
}

function chartPointClickEx(event, retChart) {
	if (event.shiftKey!=true) {
		return;
	}
	if (window.my_config.userrights!=2) {
        HideNotify();
		ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
		return;
	}
	var dateString=Highcharts.dateFormat('%Y-%m-%d', event.point.x);
	var bValid = false;
	bValid=(confirm($.i18n("Are you sure to remove this value at") + " ?:\n\nDate: " + dateString + " \nValue: " + event.point.y)==true);
	if (bValid == false) {
		return;
	}
	$.ajax({
		 url: "json.htm?type=command&param=deletedatapoint&idx=" + $.devIdx + "&date=" + dateString,
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
			if (data.status == "OK") {
				retChart($.devIdx,$.devName,$.devSwitchType);
			}
			else {
				ShowNotify($.i18n('Problem deleting data point!'), 2500, true);
			}
		 },
		 error: function(){
			ShowNotify($.i18n('Problem deleting data point!'), 2500, true);
		 }     
	}); 	
}

function chartPointClickNewEx(event, isShort, retChart) {
	if (event.shiftKey!=true) {
		return;
	}
	if (window.my_config.userrights!=2) {
        HideNotify();
		ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
		return;
	}
	var dateString;
	if (isShort==false) {
		dateString=Highcharts.dateFormat('%Y-%m-%d', event.point.x);
	}
	else {
		dateString=Highcharts.dateFormat('%Y-%m-%d %H:%M:%S', event.point.x);
	}
	var bValid = false;
	bValid=(confirm($.i18n("Are you sure to remove this value at") + " ?:\n\nDate: " + dateString + " \nValue: " + event.point.y)==true);
	if (bValid == false) {
		return;
	}
	$.ajax({
		 url: "json.htm?type=command&param=deletedatapoint&idx=" + $.devIdx + "&date=" + dateString,
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
			if (data.status == "OK") {
				retChart($.content,$.backfunction,$.devIdx,$.devName,$.devSwitchType);
			}
			else {
				ShowNotify($.i18n('Problem deleting data point!'), 2500, true);
			}
		 },
		 error: function(){
			ShowNotify($.i18n('Problem deleting data point!'), 2500, true);
		 }     
	}); 	
}

function ExportChart2CSV(chart)
{
	var csv = "";
	for (var i = 0; i < chart.series.length; i++) {
		var series = chart.series[i];
		for (var j = 0; j < series.data.length; j++) {
			if (series.data[j] != undefined && series.data[j].x >= series.xAxis.min && series.data[j].x <= series.xAxis.max) {
				csv = csv + series.name + ',' + Highcharts.dateFormat('%Y-%m-%d %H:%M:%S', series.data[j].x) + ',' + series.data[j].y + '\r\n';
			}
		}
	}
  
	var w = window.open('','csvWindow'); // popup, may be blocked though
	// the following line does not actually do anything interesting with the 
	// parameter given in current browsers, but really should have. 
	// Maybe in some browser it will. It does not hurt anyway to give the mime type
	w.document.open("text/csv");
	w.document.write(csv); // the csv string from for example a jquery plugin
	w.document.close();
}

function RefreshTimeAndSun()
{
	if (typeof $("#timesun") != 'undefined') {
		$.ajax({
		 url: "json.htm?type=command&param=getSunRiseSet",
		 async: true, 
		 dataType: 'json',
		 success: function(data) {
			if (typeof data.Sunrise != 'undefined') {
						var sunRise=data.Sunrise;
						var sunSet=data.Sunset;
						var ServerTime=data.ServerTime;
						var suntext;
						var bIsMobile=$.myglobals.ismobile;
						if (bIsMobile == true) {
							suntext=$.i18n('SunRise') + ': ' + sunRise + ', ' + $.i18n('SunSet') + ': ' + sunSet;
						}
						else {
							suntext=ServerTime + ', ' + $.i18n('SunRise') + ': ' + sunRise + ', ' + $.i18n('SunSet') + ': ' + sunSet;
						}
						$("#timesun").html(suntext);
			}
		 }
		});
	}
}

function Logout()
{
  $.ajax({
     url: "json.htm?type=command&param=logout",
     async: false, 
     dataType: 'json',
     success: function(data) {
		SwitchLayout('Dashboard');
     },
     error: function(){
		SwitchLayout('Dashboard');
     }     
  });
}

function EnableDisableTabs()
{
	$.ajax({
		 url: "json.htm?type=command&param=getactivetabs",
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
			if (typeof data.language != 'undefined') {
				SetLanguage(data.language);
			}
			else {
				SetLanguage('en');
			}
			
			var urights=data.statuscode;
			if (urights!=3) {
				if (urights!=2) {
					//no setup menu
					$("#dLogout").show();
					$("#mLogout").show();
					$("#dLogoutSetup").hide();
					$("#mLogoutSetup").hide();
				}
				else {
					$("#dLogout").hide();
					$("#mLogout").hide();
					$("#dLogoutSetup").show();
					$("#mLogoutSetup").show();
				}
			}
			else {
				$("#dLogout").hide();
				$("#mLogout").hide();
				$("#dLogoutSetup").hide();
				$("#mLogoutSetup").hide();
			}
			
			$.myglobals.ismobileint=false;
			if (typeof data.MobileType != 'undefined') {
				if( /Android|webOS|iPhone|iPad|iPod|BlackBerry/i.test(navigator.userAgent) ) {
					$.myglobals.ismobile=true;
					$.myglobals.ismobileint=true;
				}
				if (data.MobileType!=0) {
					if(!(/iPhone/i.test(navigator.userAgent) )) {
						$.myglobals.ismobile=false;
					}
				}
			}			
			if (typeof data.WindScale != 'undefined') {
				$.myglobals.windscale=parseFloat(data.WindScale);
			}
			if (typeof data.WindSign != 'undefined') {
				$.myglobals.windsign=data.WindSign;
			}

			var bAnyTabEnabled=false;
			if (data.result["EnableTabLights"]==0) {
				$("#mLightSwitches").hide();
			}
			else {
				$("#mLightSwitches").show();
				bAnyTabEnabled=true;
			}
			if (data.result["EnableTabScenes"]==0) {
				$("#mScenes").hide();
			}
			else {
				$("#mScenes").show();
				bAnyTabEnabled=true;
			}
			if (data.result["EnableTabTemp"]==0) {
				$("#mTemperature").hide();
			}
			else {
				$("#mTemperature").show();
				bAnyTabEnabled=true;
			}
			if (data.result["EnableTabWeather"]==0) {
				$("#mWeather").hide();
			}
			else {
				$("#mWeather").show();
				bAnyTabEnabled=true;
			}
			if (data.result["EnableTabUtility"]==0) {
				$("#mUtility").hide();
			}
			else {
				$("#mUtility").show();
				bAnyTabEnabled=true;
			}
			if (bAnyTabEnabled==false) {
				//nothing enabled, no need to show dashboard tab
				$("#mDashboard").hide();
			}
		 },
		 error: function(){
			if (showdialog) {
				alert($.i18n("Error communicating to server!"));
			}
		 }     
	});
}

function SetLanguage(lng)
{
	$.i18n.debug = true;
	var i18n = $.i18n({
			locale: lng
		});
	$(".nav").i18n();
}

function TranslateStatus(status)
{
	//should of course be changed, but for now a quick sollution
	if (status.indexOf("Set Level") != -1) {
		return status.replace("Set Level",$.i18n('Set Level'));
	}
	else {
		return $.i18n(status);
	}
}

function ShowGeneralGraph(id,name,switchtype,sensortype)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.devIdx=id;
  $.devName=name;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p>\n';
  htmlcontent+=$('#globaldaylog').html();
  
  var txtLabelOrg="?";
  var txtUnit="?";
  var graphReturn;
  var graphcontent;
  
  if (sensortype=="Visibility") {
	graphReturn="ShowWeathers";
	txtLabelOrg="Visibility";
	$.content="#weathercontent";
	graphcontent=$('#weathercontent');
	txtUnit="km";
	if (switchtype==1) {
		txtUnit="mi";
	}
  }
  else if (sensortype=="Radiation") {
	graphReturn="ShowWeathers";
	txtLabelOrg="Radiation";
	$.content="#weathercontent";
	graphcontent=$('#weathercontent');
	txtUnit="Watt/m2";
  }
  else if (sensortype=="Soil Moisture") {
	graphReturn="ShowUtilities";
	txtLabelOrg="Moisture";
	$.content="#utilitycontent";
	graphcontent=$('#utilitycontent');
	txtUnit="cb";
  }
  else if (sensortype=="Leaf Wetness") {
	graphReturn="ShowUtilities";
	txtLabelOrg="Wetness";
	$.content="#utilitycontent";
	graphcontent=$('#utilitycontent');
	txtUnit="Range";
  }
  else if ((sensortype=="Voltage")||(sensortype=="A/D")) {
	graphReturn="ShowUtilities";
	txtLabelOrg="Voltage";
	$.content="#utilitycontent";
	graphcontent=$('#utilitycontent');
	txtUnit="mV";
  }
  else if (switchtype=="Weight") {
	graphReturn="ShowUtilities";
	txtLabelOrg="Weight";
	$.content="#utilitycontent";
	graphcontent=$('#utilitycontent');
	txtUnit="kg";
  }
  else {
	return;
  }
  graphcontent.html(GetBackbuttonHTMLTable(graphReturn)+htmlcontent);
  graphcontent.i18n();
  
  var txtLabel= txtLabelOrg + " (" + txtUnit + ")";

	$.LogChart1 = $($.content + ' #globaldaygraph');
	$.LogChart1.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=day",
                function(data) {
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetUTCFromString(item.d), parseFloat(item.v) ] );
                      });
                      var series = $.LogChart1.highcharts().series[0];
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n(txtLabelOrg) + ' '  + Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: txtLabel
            },
			labels: {
				formatter: function() {
					if (txtUnit=="mV") {
						return Highcharts.numberFormat(this.value, 0);
					}
					return this.value;
				}
			},
			min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    Highcharts.dateFormat('%A<br/>%Y-%m-%d %H:%M', this.x) +': '+ this.y +' ' + txtUnit;
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: txtLabelOrg
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

	$.LogChart2 = $($.content + ' #globalmonthgraph');
	$.LogChart2.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=month",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseFloat(item.v_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseFloat(item.v_max) ] );
                      });
                      
                      var series1 = $.LogChart2.highcharts().series[0];
                      var series2 = $.LogChart2.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n(txtLabelOrg) + ' ' + $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: txtLabel
            },
			labels: {
				formatter: function() {
					if (txtUnit=="mV") {
						return Highcharts.numberFormat(this.value, 0);
					}
					return this.value;
				}
			},
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    Highcharts.dateFormat('%A<br/>%Y-%m-%d %H:%M', this.x) +': '+ this.y +' ' + txtUnit;
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'min',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,arguments.callee.name);
					}
				}
			}
		}, {
            name: 'max',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,arguments.callee.name);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

	$.LogChart3 = $($.content + ' #globalyeargraph');
	$.LogChart3.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=year",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseFloat(item.v_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseFloat(item.v_max) ] );
                      });
                      var series1 = $.LogChart3.highcharts().series[0];
                      var series2 = $.LogChart3.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n(txtLabelOrg) + ' ' + $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: txtLabel
            },
			labels: {
				formatter: function() {
					if (txtUnit=="mV") {
						return Highcharts.numberFormat(this.value, 0);
					}
					return this.value;
				}
			},
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    Highcharts.dateFormat('%A<br/>%Y-%m-%d %H:%M', this.x) +': '+ this.y +' ' + txtUnit;
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'min',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,arguments.callee.name);
					}
				}
			}
		}, {
            name: 'max',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,arguments.callee.name);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });
}

function AddDataToTempChart(data,chart,isday)
{
    var datatablete = [];
    var datatabletm = [];
    var datatablehu = [];
    var datatablech = [];
    var datatablecm = [];
    var datatabledp = [];
    var datatableba = [];

    $.each(data.result, function(i,item)
    {
      if (isday==1) {
        if (typeof item.te != 'undefined') {
          datatablete.push( [GetUTCFromString(item.d), parseFloat(item.te) ] );
        }
        if (typeof item.hu != 'undefined') {
          datatablehu.push( [GetUTCFromString(item.d), parseFloat(item.hu) ] );
        }
        if (typeof item.ch != 'undefined') {
          datatablech.push( [GetUTCFromString(item.d), parseFloat(item.ch) ] );
        }
        if (typeof item.dp != 'undefined') {
          datatabledp.push( [GetUTCFromString(item.d), parseFloat(item.dp) ] );
        }
        if (typeof item.ba != 'undefined') {
          datatableba.push( [GetUTCFromString(item.d), parseFloat(item.ba) ] );
        }
      } else {
        if (typeof item.te != 'undefined') {
          datatablete.push( [GetDateFromString(item.d), parseFloat(item.te) ] );
          datatabletm.push( [GetDateFromString(item.d), parseFloat(item.tm) ] );
        }
        if (typeof item.hu != 'undefined') {
          datatablehu.push( [GetDateFromString(item.d), parseFloat(item.hu) ] );
        }
        if (typeof item.ch != 'undefined') {
          datatablech.push( [GetDateFromString(item.d), parseFloat(item.ch) ] );
          datatablecm.push( [GetDateFromString(item.d), parseFloat(item.cm) ] );
        }
        if (typeof item.dp != 'undefined') {
          datatabledp.push( [GetDateFromString(item.d), parseFloat(item.dp) ] );
        }
        if (typeof item.ba != 'undefined') {
          datatableba.push( [GetDateFromString(item.d), parseFloat(item.ba) ] );
        }
      }
    });
    var series;
    if (datatablehu.length!=0)
    {
      chart.addSeries(
        {
          id: 'humidity',
          name: $.i18n('Humidity'),
          color: 'limegreen',
          yAxis: 1
        }
      );
      series = chart.get('humidity');
      series.setData(datatablehu);
    }

    if (datatablech.length!=0)
    {
      chart.addSeries(
        {
          id: 'chill',
          name: $.i18n('Chill'),
          color: 'red',
          yAxis: 0
        }
      );
      series = chart.get('chill');
      series.setData(datatablech);
      
      if (isday==0) {
        chart.addSeries(
          {
            id: 'chillmin',
            name: $.i18n('Chill') + '_min',
            color: 'rgba(255,127,39,0.8)',
            yAxis: 0
          }
        );
        series = chart.get('chillmin');
        series.setData(datatablecm);
      }
    }
    if (datatablete.length!=0)
    {
      //Add Temperature series
      chart.addSeries(
        {
          id: 'temperature',
          name: $.i18n('Temperature'),
          color: 'yellow',
          yAxis: 0
        }
      );
      series = chart.get('temperature');
      series.setData(datatablete);
      if (isday==0) {
        chart.addSeries(
          {
            id: 'temperaturemin',
            name: $.i18n('Temperature') + '_min',
            color: 'rgba(3,190,252,0.8)',
            yAxis: 0
          }
        );
        series = chart.get('temperaturemin');
        series.setData(datatabletm);
      }
    }
    if (datatabledp.length!=0)
    {
      chart.addSeries(
        {
          id: 'dewpoint',
          name: $.i18n('Dew Point'),
          color: 'blue',
          yAxis: 0
        }
      );
      series = chart.get('dewpoint');
      series.setData(datatabledp);
    }
    if (datatableba.length!=0)
    {
      chart.addSeries(
        {
          id: 'baro',
          name: $.i18n('Barometer'),
          color: 'pink',
          yAxis: 2
        }
      );
      series = chart.get('baro');
      series.setData(datatableba);
    }
}

function ShowCameraLiveStream(Name,FeedURL)
{
	$('#dialog-camera-live #camfeed').attr("src", FeedURL);

	var dwidth=$(window).width()/2;
	var dheight=$(window).height()/2;
	
	if (dwidth>630) {
		dwidth=630;
		dheight=parseInt((dwidth/16)*9);
	}
	if (dheight>470) {
		dheight=470;
		dwidth=parseInt((dheight/9)*16);
	}
	if (dwidth>dheight) {
		dwidth=parseInt((dheight/9)*16);
	}
	else {
		dheight=parseInt((dwidth/16)*9);
	}
	//Set inner Camera feed width/height
	$( "#dialog-camera-live #camfeed" ).width(dwidth-30);
	$( "#dialog-camera-live #camfeed" ).height(dheight-16);

	$( "#dialog-camera-live" ).dialog({
		resizable: false,
		width: dwidth,
		height:dheight+116,
		position: {
			my: "center",
			at: "center",
			of: window
		},
		modal: true,
		title: Name,
		buttons: {
			"OK": function() {
				$( this ).dialog( "close" );
			}
		},
		close: function() {
			$('#dialog-camera-live #camfeed').attr("src", "images/camera_default.png");
            $( this ).dialog( "close" );
		}
	});
}

function ShowTempLog(contentdiv,backfunction,id,name)
{
  clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p>\n';
  htmlcontent+=$('#daymonthyearlog').html();

  $($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
  $($.content).i18n();

  $.DayChart = $($.content + ' #daygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'line',
          zoomType: 'xy',
          alignTicks: false,
          events: {
              load: function() {
                this.showLoading();
                $.getJSON("json.htm?type=graph&sensor=temp&idx="+id+"&range=day",
                function(data) {
                      AddDataToTempChart(data,$.DayChart.highcharts(),1);
                      $.DayChart.hideLoading();
                });
                this.hideLoading();
              }
          }
      },
      loading: {
          hideDuration: 1000,
          showDuration: 1000
      },
      credits: {
        enabled: true,
        href: "http://www.domoticz.com",
        text: "Domoticz.com"
      },
      title: {
          text: $.i18n('Temperature') + ' ' + Get5MinuteHistoryDaysGraphTitle()
      },
      xAxis: {
          type: 'datetime'
      },
      yAxis: [{ //temp label
          labels:  {
                   formatter: function() {
                        return this.value +'\u00B0 C';
                   },
                   style: {
                      color: '#CCCC00'
                   }
          },
          title: {
              text: 'degrees Celsius',
               style: {
                  color: '#CCCC00'
               }
          }
      }, { //humidity label
          labels:  {
                   formatter: function() {
                        return this.value +'%';
                   },
                   style: {
                      color: 'limegreen'
                   }
          },
          title: {
              text: $.i18n('Humidity') +' %',
               style: {
                  color: '#00CC00'
               }
          },
          opposite: true
      }],
      tooltip: {
          formatter: function() {
			var unit="";
			if (this.series.name==$.i18n('Humidity')) {
				unit="%";
			}
			else if (this.series.name.indexOf($.i18n('Temperature'))==0) {
				unit="\u00B0 C";
			}
			else if (this.series.name.indexOf($.i18n('Chill'))==0) {
				unit="\u00B0 C";
			}
            return $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +'<br/>'+ this.series.name + ': ' + this.y + unit;
          }
      },
      legend: {
          enabled: true
      },
      plotOptions: {
		series: {
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,true,ShowTempLog);
					}
				}
			}
		},
	   line: {
			lineWidth: 3,
			states: {
				hover: {
					lineWidth: 3
				}
			},
			marker: {
				enabled: false,
				states: {
					hover: {
						enabled: true,
						symbol: 'circle',
						radius: 5,
						lineWidth: 1
					}
				}
			}
		}
      }
  });

  $.MonthChart = $($.content + ' #monthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          alignTicks: false,
          events: {
              load: function() {
                this.showLoading();
                $.getJSON("json.htm?type=graph&sensor=temp&idx="+id+"&range=month",
                function(data) {
                      AddDataToTempChart(data,$.MonthChart.highcharts(),0);
                      $.MonthChart.hideLoading();
                });
                this.hideLoading();
              }
          }
      },
      loading: {
          hideDuration: 1000,
          showDuration: 1000
      },
      credits: {
        enabled: true,
        href: "http://www.domoticz.com",
        text: "Domoticz.com"
      },
      title: {
          text: $.i18n('Temperature') + ' ' + $.i18n('Last Month')
      },
      xAxis: {
          type: 'datetime'
      },
      yAxis: [{ //temp label
          labels:  {
                   formatter: function() {
                        return this.value +'\u00B0 C';
                   },
                   style: {
                      color: '#CCCC00'
                   }
          },
          title: {
              text: 'degrees Celsius',
               style: {
                  color: '#CCCC00'
               }
          }
      }, { //humidity label
          labels:  {
                   formatter: function() {
                        return this.value +'%';
                   },
                   style: {
                      color: 'limegreen'
                   }
          },
          title: {
              text: $.i18n('Humidity')+' %',
               style: {
                  color: '#00CC00'
               }
          },
          opposite: true
      }],
      tooltip: {
          formatter: function() {
			var unit="";
			if (this.series.name==$.i18n('Humidity')) {
				unit="%";
			}
			else if (this.series.name.indexOf($.i18n('Temperature'))==0) {
				unit="\u00B0 C";
			}
			else if (this.series.name.indexOf($.i18n('Chill'))==0) {
				unit="\u00B0 C";
			}
            return $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +'<br/>'+ this.series.name + ': ' + this.y + unit;
          }
      },
      legend: {
          enabled: true
      },
      plotOptions: {
				series: {
					point: {
						events: {
							click: function(event) {
								chartPointClickNew(event,false,ShowTempLog);
							}
						}
					}
				},
				spline: {
                    lineWidth: 3,
                    states: {
                        hover: {
                            lineWidth: 3
                        }
                    },
                    marker: {
                        enabled: false,
                        states: {
                            hover: {
                                enabled: true,
                                symbol: 'circle',
                                radius: 5,
                                lineWidth: 1
                            }
                        }
                    }
                }
      }
  });

  $.YearChart = $($.content + ' #yeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          alignTicks: false,
          events: {
              load: function() {
                this.showLoading();
                $.getJSON("json.htm?type=graph&sensor=temp&idx="+id+"&range=year",
                function(data) {
                      AddDataToTempChart(data,$.YearChart.highcharts(),0);
                      $.YearChart.hideLoading();
                });
                this.hideLoading();
              }
          }
      },
      loading: {
          hideDuration: 1000,
          showDuration: 1000
      },
      credits: {
        enabled: true,
        href: "http://www.domoticz.com",
        text: "Domoticz.com"
      },
      title: {
          text: $.i18n('Temperature') + ' ' + $.i18n('Last Year')
      },
      xAxis: {
          type: 'datetime'
      },
      yAxis: [{ //temp label
          labels:  {
                   formatter: function() {
                        return this.value +'\u00B0 C';
                   },
                   style: {
                      color: '#CCCC00'
                   }
          },
          title: {
              text: 'degrees Celsius',
               style: {
                  color: '#CCCC00'
               }
          }
      }, { //humidity label
          labels:  {
                   formatter: function() {
                        return this.value +'%';
                   },
                   style: {
                      color: 'limegreen'
                   }
          },
          title: {
              text: $.i18n('Humidity')+' %',
               style: {
                  color: '#00CC00'
               }
          },
          opposite: true
      }],
      tooltip: {
          formatter: function() {
			var unit="";
			if (this.series.name==$.i18n('Humidity')) {
				unit="%";
			}
			else if (this.series.name.indexOf($.i18n('Temperature'))==0) {
				unit="\u00B0 C";
			}
			else if (this.series.name.indexOf($.i18n('Chill'))==0) {
				unit="\u00B0 C";
			}
            return $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +'<br/>'+ this.series.name + ': ' + this.y + unit;
          }
      },
      legend: {
          enabled: true
      },
      plotOptions: {
				series: {
					point: {
						events: {
							click: function(event) {
								chartPointClickNew(event,false,ShowTempLog);
							}
						}
					}
				},
				spline: {
                    lineWidth: 3,
                    states: {
                        hover: {
                            lineWidth: 3
                        }
                    },
                    marker: {
                        enabled: false,
                        states: {
                            hover: {
                                enabled: true,
                                symbol: 'circle',
                                radius: 5,
                                lineWidth: 1
                            }
                        }
                    }
                }
      }
  });

  $('#modal').hide();
  cursordefault();
  return true;
}

function ShowUVLog(contentdiv,backfunction,id,name)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p><br>\n';
  htmlcontent+=$('#daymonthyearlog').html();
  $($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
  $($.content).i18n();
  
  $.DayChart = $($.content + ' #daygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=uv&idx="+id+"&range=day",
                function(data) {
                      var series = $.DayChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetUTCFromString(item.d), parseFloat(item.uvi) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: 'UV '  + Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'UV (UVI)'
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' UVI';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'uv',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,true,ShowUVLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.MonthChart = $($.content + ' #monthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=uv&idx="+id+"&range=month",
                function(data) {
                      var series = $.MonthChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetDateFromString(item.d), parseFloat(item.uvi) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: 'UV ' + $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'UV (UVI)'
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' UVI';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'uv',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowUVLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.YearChart = $($.content + ' #yeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=uv&idx="+id+"&range=year",
                function(data) {
                      var series = $.YearChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetDateFromString(item.d), parseFloat(item.uvi) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: 'UV ' + $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'UV (UVI)'
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' UVI';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'uv',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowUVLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });
  $('#modal').hide();
  cursordefault();
  return false;
}

function ShowWindLog(contentdiv,backfunction,id,name)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  var htmlcontent = '';
        
  htmlcontent='<p><center><h2>' + name + '</h2></center></p><br>\n';
  htmlcontent+=$('#windlog').html();
  $($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
  $($.content).i18n();
  
  $.DayChart = $($.content + ' #winddaygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                $.getJSON("json.htm?type=graph&sensor=wind&idx="+id+"&range=day",
                function(data) {
                      var seriessp = $.DayChart.highcharts().series[0];
                      var seriesgu = $.DayChart.highcharts().series[1];
                      var datatablesp = [];
                      var datatablegu = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatablesp.push( [GetUTCFromString(item.d), parseFloat(item.sp) ] );
                        datatablegu.push( [GetUTCFromString(item.d), parseFloat(item.gu) ] );
                      });
                      seriessp.setData(datatablesp);
                      seriesgu.setData(datatablegu);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Wind') + ' ' + $.i18n('speed/gust') + ' '  + Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Speed') + ' (' + $.myglobals.windsign + ')'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null,
            plotBands: [{ // Light air
                from: 0.3*$.myglobals.windscale,
                to: 1.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Light air'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Light breeze
                from: 1.5*$.myglobals.windscale,
                to: 3.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Light breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Gentle breeze
                from: 3.5*$.myglobals.windscale,
                to: 5.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Gentle breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Moderate breeze
                from: 5.5*$.myglobals.windscale,
                to: 8*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Moderate breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Fresh breeze
                from: 8*$.myglobals.windscale,
                to: 10.8*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Fresh breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Strong breeze
                from: 10.8*$.myglobals.windscale,
                to: 13.9*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Strong breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // High wind
                from: 13.9*$.myglobals.windscale,
                to: 17.2*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('High wind'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // fresh gale
                from: 17.2*$.myglobals.windscale,
                to: 20.8*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Fresh gale'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // strong gale
                from: 20.8*$.myglobals.windscale,
                to: 24.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Strong gale'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // storm
                from: 24.5*$.myglobals.windscale,
                to: 28.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Storm'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Violent storm
                from: 28.5*$.myglobals.windscale,
                to: 32.7*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Violent storm'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // hurricane
                from: 32.7*$.myglobals.windscale,
                to: 100*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Hurricane'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }
            ]
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' ' + $.myglobals.windsign;
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: $.i18n('Speed')
        }, {
            name: $.i18n('Gust')
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.DirChart = $($.content + ' #winddirgraph');
  $.DirChart.highcharts({
      chart: {
          polar: true,
          events: {
              load: function() {
                $.getJSON("json.htm?type=graph&sensor=winddir&idx="+id+"&range=day",
                function(data) {
                      var series = $.DirChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [item.dig, parseFloat(item.div) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
        title: {
            text: $.i18n('Wind') + ' ' + $.i18n('Direction') + ' '  + Get5MinuteHistoryDaysGraphTitle()
        },
        pane: {
            startAngle: 0,
            endAngle: 360
        },
        credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        xAxis: {
            min: 0,
            max: 360,
            tickWidth: 1,
            tickPosition: 'outside',
            tickLength: 20,
            tickColor: '#999',
            tickInterval:45,
            labels: {
                formatter:function(){
                    if(this.value == 0) { return 'N'; }
                    else if(this.value == 45) { return 'NE'; }
                    else if(this.value == 90) { return 'E'; }
                    else if(this.value == 135) { return 'SE'; }
                    else if(this.value == 180) { return 'S'; }
                    else if(this.value == 225) { return 'SW'; }
                    else if(this.value == 270) { return 'W'; }
                    else if(this.value == 315) { return 'NW'; }
                }
            }
        },
        yAxis: {
            min: 0
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    this.x +'\u00B0: '+ this.y +' %';
            }
        },
        plotOptions: {
            area: {
                lineWidth: 2,
                states: {
                    hover: {
                        lineWidth: 2
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            type: 'area',
            color: 'rgba(68, 170, 213, 0.2)',
            name: $.i18n('Direction')
        }]
    });

  $.MonthChart = $($.content + ' #windmonthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=wind&idx="+id+"&range=month",
                function(data) {
                      var seriessp = $.MonthChart.highcharts().series[0];
                      var seriesgu = $.MonthChart.highcharts().series[1];
                      var datatablesp = [];
                      var datatablegu = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatablesp.push( [GetDateFromString(item.d), parseFloat(item.sp) ] );
                        datatablegu.push( [GetDateFromString(item.d), parseFloat(item.gu) ] );
                      });
                      seriessp.setData(datatablesp);
                      seriesgu.setData(datatablegu);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Wind') + ' ' + $.i18n('speed/gust') + ' ' + $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Speed') + ' (' + $.myglobals.windsign + ')'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null,
            plotBands: [{ // Light air
                from: 0.3*$.myglobals.windscale,
                to: 1.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Light air'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Light breeze
                from: 1.5*$.myglobals.windscale,
                to: 3.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Light breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Gentle breeze
                from: 3.5*$.myglobals.windscale,
                to: 5.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Gentle breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Moderate breeze
                from: 5.5*$.myglobals.windscale,
                to: 8*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Moderate breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Fresh breeze
                from: 8*$.myglobals.windscale,
                to: 10.8*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Fresh breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Strong breeze
                from: 10.8*$.myglobals.windscale,
                to: 13.9*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Strong breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // High wind
                from: 13.9*$.myglobals.windscale,
                to: 17.2*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('High wind'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // fresh gale
                from: 17.2*$.myglobals.windscale,
                to: 20.8*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Fresh gale'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // strong gale
                from: 20.8*$.myglobals.windscale,
                to: 24.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Strong gale'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // storm
                from: 24.5*$.myglobals.windscale,
                to: 28.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Storm'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Violent storm
                from: 28.5*$.myglobals.windscale,
                to: 32.7*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Violent storm'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // hurricane
                from: 32.7*$.myglobals.windscale,
                to: 100*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Hurricane'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }
           ]
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' ' + $.myglobals.windsign;
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: $.i18n('Speed'),
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowWindLog);
					}
				}
			}
        }, {
            name: $.i18n('Gust'),
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowWindLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.YearChart = $($.content + ' #windyeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=wind&idx="+id+"&range=year",
                function(data) {
                      var seriessp = $.YearChart.highcharts().series[0];
                      var seriesgu = $.YearChart.highcharts().series[1];
                      var datatablesp = [];
                      var datatablegu = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatablesp.push( [GetDateFromString(item.d), parseFloat(item.sp) ] );
                        datatablegu.push( [GetDateFromString(item.d), parseFloat(item.gu) ] );
                      });
                      seriessp.setData(datatablesp);
                      seriesgu.setData(datatablegu);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Wind') + ' ' + $.i18n('speed/gust') + ' ' + $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Speed') + ' (' + $.myglobals.windsign + ')'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null,
            plotBands: [{ // Light air
                from: 0.3*$.myglobals.windscale,
                to: 1.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Light air'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Light breeze
                from: 1.5*$.myglobals.windscale,
                to: 3.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Light breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Gentle breeze
                from: 3.5*$.myglobals.windscale,
                to: 5.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Gentle breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Moderate breeze
                from: 5.5*$.myglobals.windscale,
                to: 8*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Moderate breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Fresh breeze
                from: 8*$.myglobals.windscale,
                to: 10.8*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Fresh breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Strong breeze
                from: 10.8*$.myglobals.windscale,
                to: 13.9*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Strong breeze'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // High wind
                from: 13.9*$.myglobals.windscale,
                to: 17.2*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('High wind'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // fresh gale
                from: 17.2*$.myglobals.windscale,
                to: 20.8*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Fresh gale'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // strong gale
                from: 20.8*$.myglobals.windscale,
                to: 24.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Strong gale'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // storm
                from: 24.5*$.myglobals.windscale,
                to: 28.5*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Storm'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Violent storm
                from: 28.5*$.myglobals.windscale,
                to: 32.7*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Violent storm'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // hurricane
                from: 32.7*$.myglobals.windscale,
                to: 100*$.myglobals.windscale,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Hurricane'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }
           ]
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' ' + $.myglobals.windsign;
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: $.i18n('Speed'),
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowWindLog);
					}
				}
			}
        }, {
            name: $.i18n('Gust'),
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowWindLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });
  $('#modal').hide();
  cursordefault();
  return false;
}

function ShowRainLog(contentdiv,backfunction,id,name)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p>\n';
  htmlcontent+=$('#dayweekmonthyearlog').html();
  $($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
  $($.content).i18n();

  $.DayChart = $($.content + ' #daygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'column',
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=rain&idx="+id+"&range=day",
                function(data) {
                      var series = $.DayChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetUTCFromString(item.d), parseFloat(item.mm) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Rainfall') + ' ' + Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            min: 0,
            maxPadding: 0.2,
            endOnTick: false,
            title: {
                text: $.i18n('Rainfall') + ' (mm)'
            }
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' mm';
            }
        },
        plotOptions: {
            column: {
                minPointLength: 3,
                pointPadding: 0.1,
                groupPadding: 0,
				dataLabels: {
                        enabled: false,
                        color: 'white'
                }                
            }
        },
        series: [{
            name: 'mm',
            color: 'rgba(3,190,252,0.8)'
        }]
        ,
        legend: {
            enabled: false
        }
    });

  $.WeekChart = $($.content + ' #weekgraph');
  $.WeekChart.highcharts({
      chart: {
          type: 'column',
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=rain&idx="+id+"&range=week",
                function(data) {
                      var series = $.WeekChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetDateFromString(item.d), parseFloat(item.mm) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Rainfall') + ' ' + $.i18n('Last Week')
        },
        xAxis: {
            type: 'datetime',
            dateTimeLabelFormats: {
                day: '%a'
            },
            tickInterval: 24 * 3600 * 1000
        },
        yAxis: {
            min: 0,
            maxPadding: 0.2,
            endOnTick: false,
            title: {
                text: $.i18n('Rainfall') + ' (mm)'
            }
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d', this.x) +': '+ this.y +' mm';
            }
        },
        plotOptions: {
            column: {
                minPointLength: 4,
                pointPadding: 0.1,
                groupPadding: 0,
				dataLabels: {
                        enabled: true,
                        color: 'white'
                }                
            }
        },
        series: [{
            name: 'mm',
            color: 'rgba(3,190,252,0.8)'
        }]
        ,
        legend: {
            enabled: false
        }
    });

  $.MonthChart = $($.content + ' #monthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          marginRight: 10,
          zoomType: 'xy',
          events: {
              load: function() {
                $.getJSON("json.htm?type=graph&sensor=rain&idx="+id+"&range=month",
                function(data) {
                      var series = $.MonthChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetDateFromString(item.d), parseFloat(item.mm) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Rainfall') + ' ' + $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Rainfall') + ' (mm)'
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d', this.x) +': '+ this.y +' mm';
            }
        },
        plotOptions: {
           spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'mm',
            color: 'rgba(3,190,252,0.8)',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowRainLog);
					}
				}
			}
        }]
        ,
        legend: {
            enabled: false
        }
    });

  $.YearChart = $($.content + ' #yeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          marginRight: 10,
          zoomType: 'xy',
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=rain&idx="+id+"&range=year",
                function(data) {
                      var series = $.YearChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetDateFromString(item.d), parseFloat(item.mm) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Rainfall') + ' ' + $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Rainfall') + ' (mm)'
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d', this.x) +': '+ this.y +' mm';
            }
        },
        plotOptions: {
           spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'mm',
            color: 'rgba(3,190,252,0.8)',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowRainLog);
					}
				}
			}
        }]
        ,
        legend: {
            enabled: false
        }
    });
  $('#modal').hide();
  cursordefault();
  return false;
}

function ShowBaroLog(contentdiv,backfunction,id,name)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p><br>\n';
  htmlcontent+=$('#daymonthyearlog').html();
  $($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
  $($.content).i18n();
  
  $.DayChart = $($.content + ' #daygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=temp&idx="+id+"&range=day",
                function(data) {
                      var series = $.DayChart.highcharts().series[0];
                      var datatable = [];
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetUTCFromString(item.d), parseFloat(item.ba) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Barometer') + ' '  + Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Pressure') + ' (hPa)'
            },
            labels: {
							formatter: function(){
									return this.value;       
							}
						}
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' hPa';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'hPa',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,true,ShowBaroLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.MonthChart = $($.content + ' #monthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=temp&idx="+id+"&range=month",
                function(data) {
                      var series = $.MonthChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetDateFromString(item.d), parseFloat(item.ba) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Barometer') + ' ' + $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Pressure') + ' (hPa)'
            },
            labels: {
							formatter: function(){
									return this.value;       
							}
						}
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' hPa';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'hPa',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowBaroLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.YearChart = $($.content + ' #yeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=temp&idx="+id+"&range=year",
                function(data) {
                      var series = $.YearChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetDateFromString(item.d), parseFloat(item.ba) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Barometer') + ' ' + $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Pressure') + ' (hPa)'
            },
            labels: {
							formatter: function(){
									return this.value;       
							}
						}
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' hPa';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'hPa',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowBaroLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });
  $('#modal').hide();
  cursordefault();
  return false;
}

function ShowAirQualityLog(contentdiv,backfunction,id,name)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p>\n';
  htmlcontent+=$('#daymonthyearlog').html();
  $($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
  $($.content).i18n();

  $.DayChart = $($.content + ' #daygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=day",
                function(data) {
                      var series = $.DayChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetUTCFromString(item.d), parseInt(item.co2) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Air Quality') + ' '  + Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'co2 (ppm)'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null,
            plotBands: [{ // Excellent
                from: 0,
                to: 700,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Excellent'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Good
                from: 700,
                to: 900,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Good'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Fair
                from: 900,
                to: 1100,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Fair'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Mediocre
                from: 1100,
                to: 1600,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Mediocre'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Bad
                from: 1600,
                to: 6000,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Bad'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }
           ]
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' ppm';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'co2',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowAirQualityLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.MonthChart = $($.content + ' #monthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=month",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseInt(item.co2_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseInt(item.co2_max) ] );
                      });
                      var series1 = $.MonthChart.highcharts().series[0];
                      var series2 = $.MonthChart.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Air Quality') + ' ' + $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'co2 (ppm)'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null,
            plotBands: [{ // Excellent
                from: 0,
                to: 700,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Excellent'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Good
                from: 700,
                to: 900,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Good'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Fair
                from: 900,
                to: 1100,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Fair'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Mediocre
                from: 1100,
                to: 1600,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Mediocre'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Bad
                from: 1600,
                to: 6000,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Bad'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }
           ]
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' ppm';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'co2_min',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowAirQualityLog);
					}
				}
			}
		}, {
            name: 'co2_max',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowAirQualityLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.YearChart = $($.content + ' #yeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=year",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseInt(item.co2_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseInt(item.co2_max) ] );
                      });
                      var series1 = $.YearChart.highcharts().series[0];
                      var series2 = $.YearChart.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Air Quality') + ' ' + $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'co2 (ppm)'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null,
            plotBands: [{ // Excellent
                from: 0,
                to: 700,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Excellent'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Good
                from: 700,
                to: 900,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Good'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Fair
                from: 900,
                to: 1100,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Fair'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Mediocre
                from: 1100,
                to: 1600,
                color: 'rgba(68, 170, 213, 0.5)',
                label: {
                    text: $.i18n('Mediocre'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }, { // Bad
                from: 1600,
                to: 6000,
                color: 'rgba(68, 170, 213, 0.3)',
                label: {
                    text: $.i18n('Bad'),
                    style: {
                        color: '#CCCCCC'
                    }
                }
            }
           ]
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' ppm';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'co2_min',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowAirQualityLog);
					}
				}
			}
		}, {
            name: 'co2_max',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowAirQualityLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });
  $('#modal').hide();
  cursordefault();
  return false;
}


function ShowFanLog(contentdiv,backfunction,id,name)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p>\n';
  htmlcontent+=$('#daymonthyearlog').html();
  $($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
  $($.content).i18n();  
  
  $.DayChart = $($.content + ' #daygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=fan&idx="+id+"&range=day",
                function(data) {
                      var series = $.DayChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetUTCFromString(item.d), parseInt(item.v) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('RPM') + ' '  + Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'RPM'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' rpm';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'RPM'
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });
  
  $.MonthChart = $($.content + ' #monthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=fan&idx="+id+"&range=month",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseInt(item.v_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseInt(item.v_max) ] );
                      });
                      var series1 = $.MonthChart.highcharts().series[0];
                      var series2 = $.MonthChart.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('RPM') + ' ' + $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'RPM'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' RPM';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'min',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,ShowFanLog);
					}
				}
			}
		}, {
            name: 'max',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,ShowFanLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.YearChart = $($.content + ' #yeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=fan&idx="+id+"&range=year",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseInt(item.v_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseInt(item.v_max) ] );
                      });
                      var series1 = $.YearChart.highcharts().series[0];
                      var series2 = $.YearChart.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('RPM') + ' ' + $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'RPM'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' RPM';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'min',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,ShowFanLog);
					}
				}
			}
		}, {
            name: 'max',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,ShowFanLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });
	$('#modal').hide();
  cursordefault();
  return false;
}


function ShowPercentageLog(contentdiv,backfunction,id,name)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p>\n';
  htmlcontent+=$('#daymonthyearlog').html();
  $($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
  $($.content).i18n();  
  
  $.DayChart = $($.content + ' #daygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=load&idx="+id+"&range=day",
                function(data) {
                      var series = $.DayChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetUTCFromString(item.d), parseInt(item.v) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Percentage') + ' '  + Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'Percentage'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' %';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'Percentage'
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });
  
  $.MonthChart = $($.content + ' #monthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=load&idx="+id+"&range=month",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseInt(item.v_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseInt(item.v_max) ] );
                      });
                      var series1 = $.MonthChart.highcharts().series[0];
                      var series2 = $.MonthChart.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Percentage') + ' ' + $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'Percentage'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' %';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'min',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,ShowPercentageLog);
					}
				}
			}
		}, {
            name: 'max',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,ShowPercentageLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.YearChart = $($.content + ' #yeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=load&idx="+id+"&range=year",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseInt(item.v_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseInt(item.v_max) ] );
                      });
                      var series1 = $.YearChart.highcharts().series[0];
                      var series2 = $.YearChart.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Percentage') + ' ' + $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'Percentage'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' %';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'min',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,ShowPercentageLog);
					}
				}
			}
		}, {
            name: 'max',
			point: {
				events: {
					click: function(event) {
						chartPointClick(event,ShowPercentageLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });
	$('#modal').hide();
  cursordefault();
  return false;
}




function AddDataToUtilityChart(data,chart,switchtype)
{
    var datatableUsage1 = [];
    var datatableUsage2 = [];
    var datatableReturn1 = [];
    var datatableReturn2 = [];
    var datatableTotalUsage = [];
    var datatableTotalReturn = [];

	var bHaveDelivered=(typeof data.delivered!= 'undefined');
	
    $.each(data.result, function(i,item)
    {
			if (chart == $.DayChart) {
				var cdate=GetUTCFromString(item.d);
				datatableUsage1.push( [cdate, parseFloat(item.v) ] );
				if (typeof item.v2!= 'undefined') {
					datatableUsage2.push( [cdate, parseFloat(item.v2) ] );
				}
				if (bHaveDelivered) {
					datatableReturn1.push( [cdate, parseFloat(item.r1) ] );
					if (typeof item.r2!= 'undefined') {
						datatableReturn2.push( [cdate, parseFloat(item.r2) ] );
					}
				}
			}
			else {
				var cdate=GetDateFromString(item.d);
				datatableUsage1.push( [cdate, parseFloat(item.v) ] );
				if (typeof item.v2!= 'undefined') {
					datatableUsage2.push( [cdate, parseFloat(item.v2) ] );
				}
				if (bHaveDelivered) {
					datatableReturn1.push( [cdate, parseFloat(item.r1) ] );
					if (typeof item.r2!= 'undefined') {
						datatableReturn2.push( [cdate, parseFloat(item.r2) ] );
					}
				}
				if (datatableUsage2.length>0) {
					datatableTotalUsage.push( [cdate, parseFloat(item.v)+parseFloat(item.v2) ] );
				}
				else {
					datatableTotalUsage.push( [cdate, parseFloat(item.v) ] );
				}
				if (datatableUsage2.length>0) {
					datatableTotalReturn.push( [cdate, parseFloat(item.r1)+parseFloat(item.r2) ] );
				}
				else {
					datatableTotalReturn.push( [cdate, parseFloat(item.r1) ] );
				}
			}
    });

    var series;
    if (switchtype==0)
    {
		if ((chart == $.DayChart)||(chart == $.WeekChart)) {
			if (datatableUsage1.length>0) {
				if (datatableUsage2.length>0) {
					chart.highcharts().addSeries({
					  id: 'usage1',
					  name: 'Usage_1',
					  color: 'rgba(60,130,252,0.8)',
					  stack: 'susage',
					  yAxis: 0
					});
				}
				else {
					chart.highcharts().addSeries({
					  id: 'usage1',
					  name: 'Usage',
					  color: 'rgba(3,190,252,0.8)',
					  stack: 'susage',
					  yAxis: 0
					});
				}
				series = chart.highcharts().get('usage1');
				series.setData(datatableUsage1);
			}
			if (datatableUsage2.length>0) {
				chart.highcharts().addSeries({
				  id: 'usage2',
				  name: 'Usage_2',
				  color: 'rgba(3,190,252,0.8)',
				  stack: 'susage',
				  yAxis: 0
				});
				series = chart.highcharts().get('usage2');
				series.setData(datatableUsage2);
			}
			if (bHaveDelivered) {
				if (datatableReturn1.length>0) {
					chart.highcharts().addSeries({
						id: 'return1',
						name: 'Return_1',
						color: 'rgba(30,242,110,0.8)',
						stack: 'sreturn',
						yAxis: 0
					});
					series = chart.highcharts().get('return1');
					series.setData(datatableReturn1);
				}
				if (datatableReturn2.length>0) {
					chart.highcharts().addSeries({
						id: 'return2',
						name: 'Return_2',
						color: 'rgba(3,252,190,0.8)',
						stack: 'sreturn',
						yAxis: 0
					});
					series = chart.highcharts().get('return2');
					series.setData(datatableReturn2);
				}
			}
		}
		else {
			//month/year, show total for now
			if (datatableTotalUsage.length>0) {
				chart.highcharts().addSeries({
				  id: 'usage',
				  name: 'Total_Usage',
				  color: 'rgba(3,190,252,0.8)',
				  yAxis: 0
				});
				series = chart.highcharts().get('usage');
				series.setData(datatableTotalUsage);
			}
			if (bHaveDelivered) {
				if (datatableTotalReturn.length>0) {
					chart.highcharts().addSeries({
						id: 'return',
						name: 'Total_Return',
						color: 'rgba(3,252,190,0.8)',
						yAxis: 0
					});
					series = chart.highcharts().get('return');
					series.setData(datatableTotalReturn);
				}
			}
		}
		if (chart == $.DayChart) {
			chart.highcharts().yAxis[0].axisTitle.attr({
				text: $.i18n('Energy') + ' Watt'
			});			
		}
		else {
			chart.highcharts().yAxis[0].axisTitle.attr({
				text: $.i18n('Energy') + ' kWh'
			});			
		}
		chart.highcharts().yAxis[0].redraw();
    }
    else if (switchtype==1)
    {
		//gas
		chart.highcharts().addSeries({
          id: 'gas',
          name: 'Gas',
          color: 'rgba(3,190,252,0.8)',
          yAxis: 0
        });
		chart.highcharts().yAxis[0].axisTitle.attr({
			text: 'Gas m3'
		});			
		series = chart.highcharts().get('gas');
		series.setData(datatableUsage1);
    }
    else if (switchtype==2)
    {
		//water
		chart.highcharts().addSeries({
          id: 'water',
          name: 'Water',
          color: 'rgba(3,190,252,0.8)',
          yAxis: 0
        });
		chart.highcharts().yAxis[0].axisTitle.attr({
			text: 'Water m3'
		});			
		series = chart.highcharts().get('water');
		series.setData(datatableUsage1);
    }
    else if (switchtype==3)
    {
		//counter
		chart.highcharts().addSeries({
          id: 'counter',
          name: 'Counter',
          color: 'rgba(3,190,252,0.8)',
          yAxis: 0
        });
		chart.highcharts().yAxis[0].axisTitle.attr({
			text: 'Count'
		});			
		series = chart.highcharts().get('counter');
		series.setData(datatableUsage1);
    }
}


function ShowSmartLog(contentdiv,backfunction,id,name,switchtype)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  $.devSwitchType=switchtype;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p>\n';
  htmlcontent+=$('#dayweekmonthyearlog').html();

	$.costsT1=0.2389;
	$.costsT2=0.2389;
	$.costsGas=0.6218;

	$.ajax({
		 url: "json.htm?type=command&param=getelectragascosts&idx="+$.devIdx,
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
			$.costsT1=parseFloat(data.CostEnergy)/10000;
			$.costsT2=parseFloat(data.CostEnergyT2)/10000;
			$.costsGas=parseFloat(data.CostGas)/10000;
			$.CounterT1=parseFloat(data.CounterT1);
			$.CounterT2=parseFloat(data.CounterT2);
			$.CounterR1=parseFloat(data.CounterR1);
			$.CounterR2=parseFloat(data.CounterR2);
		 }
	});

	$.costsR1=$.costsT1;
	$.costsR2=$.costsT2;

	$.monthNames = [ "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December" ];
    
	var d = new Date();
	var actMonth = d.getMonth()+1;
	var actYear = d.getYear()+1900;

  $($.content).html(GetBackbuttonHTMLTableWithRight(backfunction,'ShowP1YearReport('+actYear+')',$.i18n('Report'))+htmlcontent);
  $($.content).i18n();
  
  $.DayChart = $($.content + ' #daygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'line',
          zoomType: 'xy',
          events: {
              load: function() {
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=day",
                function(data) {
					AddDataToUtilityChart(data,$.DayChart,switchtype);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
				title: {
					text: $.i18n('Usage')
				},
				min: 0,
				endOnTick: false,
				startOnTick: false
		},
        tooltip: {
            formatter: function() {
				var unit = {
								'Usage': 'Watt',
								'Usage_1': 'Watt',
								'Usage_2': 'Watt',
								'Return_1': 'Watt',
								'Return_2': 'Watt',
								'Gas': 'm3',
								'Water': 'm3'
							}[this.series.name];
				return $.i18n(Highcharts.dateFormat('%A',this.x)) + ' ' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) + '<br />' + this.series.name + ':  ' + this.y + ' ' + unit;
            }
        },
        plotOptions: {
			line: {
				lineWidth: 3,
				states: {
					hover: {
							lineWidth: 3
					}
				},
				marker: {
					enabled: false,
					states: {
							hover: {
									enabled: true,
									symbol: 'circle',
									radius: 5,
									lineWidth: 1
							}
					}
				}
			}
        },
        legend: {
            enabled: true
        }
    });
  
  $.WeekChart = $($.content + ' #weekgraph');
  $.WeekChart.highcharts({
      chart: {
          type: 'column',
          marginRight: 10,
          events: {
              load: function() {
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=week",
                function(data) {
					AddDataToUtilityChart(data,$.WeekChart,switchtype);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Last Week')
        },
        xAxis: {
            type: 'datetime',
            dateTimeLabelFormats: {
                day: '%a'
            },
            tickInterval: 24 * 3600 * 1000
        },
        yAxis: {
            title: {
                text: $.i18n('Energy') + ' (kWh)'
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
					var unit = {
						'Usage': 'Watt',
						'Usage_1': 'kWh',
						'Usage_2': 'kWh',
						'Return_1': 'kWh',
						'Return_2': 'kWh',
						'Gas': 'm3',
						'Water': 'm3'
					}[this.series.name];
                    return $.i18n(Highcharts.dateFormat('%A',this.x)) + ' ' + Highcharts.dateFormat('%Y-%m-%d', this.x) +'<br/>'+ this.series.name + ': ' + this.y + ' ' + unit + '<br/>Total: '+ this.point.stackTotal + ' ' + unit;
            }
        },
        plotOptions: {
            column: {
				stacking: 'normal',
                minPointLength: 4,
                pointPadding: 0.1,
                groupPadding: 0
            }
        },
        legend: {
            enabled: true
        }
    });

  $.MonthChart = $($.content + ' #monthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          marginRight: 10,
          zoomType: 'xy',
          events: {
              load: function() {
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=month",
                function(data) {
					AddDataToUtilityChart(data,$.MonthChart,switchtype);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Usage')
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
					var unit = {
						'Usage': 'Watt',
						'Usage_1': 'kWh',
						'Usage_2': 'kWh',
						'Return_1': 'kWh',
						'Return_2': 'kWh',
						'Total_Usage': 'kWh',
						'Total_Return': 'kWh',
						'Gas': 'm3',
						'Water': 'm3'
					}[this.series.name];
                    return $.i18n(Highcharts.dateFormat('%A',this.x)) + ' ' + Highcharts.dateFormat('%Y-%m-%d', this.x) + '<br/>' + this.series.name + ': ' + this.y.toFixed(2) + ' ' + unit;
            }
        },
        plotOptions: {
			series: {
				point: {
					events: {
						click: function(event) {
							chartPointClickNewEx(event,false,ShowSmartLog);
						}
					}
				}
			},
			spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        legend: {
            enabled: true
        }
    });

  $.YearChart = $($.content + ' #yeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          marginRight: 10,
          zoomType: 'xy',
          events: {
              load: function() {
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=year",
                function(data) {
					AddDataToUtilityChart(data,$.YearChart,switchtype);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Usage')
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
					var unit = {
						'Usage': 'Watt',
						'Usage_1': 'kWh',
						'Usage_2': 'kWh',
						'Return_1': 'kWh',
						'Return_2': 'kWh',
						'Total_Usage': 'kWh',
						'Total_Return': 'kWh',
						'Gas': 'm3',
						'Water': 'm3'
					}[this.series.name];
                    return $.i18n(Highcharts.dateFormat('%A',this.x)) + ' ' + Highcharts.dateFormat('%Y-%m-%d', this.x) + '<br/>' + this.series.name + ': ' +  this.y.toFixed(2) + ' ' + unit;
            }
        },
        plotOptions: {
			series: {
				point: {
					events: {
						click: function(event) {
							chartPointClickNewEx(event,false,ShowSmartLog);
						}
					}
				}
			},
			spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        legend: {
            enabled: true
        }
    });
}

function OnSelChangeYearP1ReportGas()
{
	var yearidx=$($.content + ' #comboyear option:selected').val();
	if (typeof yearidx == 'undefined') {
		return ;
	}
	ShowP1YearReportGas(yearidx);
}

function ShowP1MonthReportGas(actMonth,actYear)
{
  var htmlcontent = '';

  htmlcontent+=$('#toptextmonthgas').html();
  htmlcontent+=$('#monthreportviewgas').html();
  $($.content).html(htmlcontent);
  $($.content).i18n();

  $($.content + ' #theader').html($.i18n("Usage")+ " "+ $.i18n($.monthNames[actMonth-1])+" " + actYear);

	if ($.devSwitchType==0) {
		//Electra
		$($.content + ' #munit').html("kWh");
	}
	else {
		//Gas
		$($.content + ' #munit').html("m3");
	}

  $($.content + ' #monthreport').dataTable( {
		"sDom": '<"H"rC>t<"F">',
		"oTableTools": {
			"sRowSelect": "single"
		},
		"aaSorting": [[ 0, "asc" ]],
		"aoColumnDefs": [
			{ "bSortable": false, "aTargets": [ 3 ] }
		],
		"bSortClasses": false,
		"bProcessing": true,
		"bStateSave": false,
		"bJQueryUI": true,
		"aLengthMenu": [[50, 100, -1], [50, 100, "All"]],
		"iDisplayLength" : 50
  });
  var mTable = $($.content + ' #monthreport');
  var oTable = mTable.dataTable();
  //some test data
  oTable.fnClearTable();
  
  var total=0;
  
	$.getJSON("json.htm?type=graph&sensor=counter&idx="+$.devIdx+"&range=year&actmonth="+actMonth+"&actyear="+actYear,
	function(data) {
		var lastTotal=-1;
		
	    $.each(data.result, function(i,item)
		{
			var month=parseInt(item.d.substring(5, 7), 10);
			var year=parseInt(item.d.substring(0, 4), 10);

			if ((month==actMonth)&&(year==actYear)) {
				var day=parseInt(item.d.substring(8, 10), 10);
				var Usage=parseFloat(item.v);
			
				total+=Usage;

				var rcost;
				if ($.devSwitchType==0) {
					//Electra
					rcost=Usage*$.costsT1;
				}
				else {
					//Gas
					rcost=Usage*$.costsGas;
				}

				var img;
				if ((lastTotal==-1)||(lastTotal==Usage)) {
					img='<img src="images/equal.png"></img>';
				}
				else if (Usage<lastTotal) {
					img='<img src="images/down.png"></img>';
				}
				else {
					img='<img src="images/up.png"></img>';
				}
				lastTotal=Usage;

				var addId = oTable.fnAddData([
					  day,
					  Usage.toFixed(3),
					  rcost.toFixed(2),
					  img
					], false);
			}
		});

	  $($.content + ' #tu').html(total.toFixed(3));
	  
		var montlycosts;
		if ($.devSwitchType==0) {
			//Electra
			montlycosts=(total*$.costsT1)
		}
		else {
			//Gas
			montlycosts=(total*$.costsGas)
		}
		$($.content + ' #mc').html(montlycosts.toFixed(2));
	  
	  mTable.fnDraw();
		/* Add a click handler to the rows - this could be used as a callback */
		$($.content + ' #monthreport tbody tr').click( function( e ) {
			if ( $(this).hasClass('row_selected') ) {
				$(this).removeClass('row_selected');
			}
			else {
				oTable.$('tr.row_selected').removeClass('row_selected');
				$(this).addClass('row_selected');
			}
		});  
	});

  return false;
}
function addLeadingZeros(n, length)
{
    var str = (n > 0 ? n : -n) + "";
    var zeros = "";
    for (var i = length - str.length; i > 0; i--)
        zeros += "0";
    zeros += str;
    return n >= 0 ? zeros : "-" + zeros;
}

function Add2YearTableP1ReportGas(oTable,total,lastTotal,lastMonth,actYear)
{
	var rcost;
	if ($.devSwitchType==0) {
		//Electra
		rcost=total*$.costsT1;
	}
	else {
		//Gas
		rcost=total*$.costsGas;
	}

	var img;
	if ((lastTotal==-1)||(lastTotal==total)) {
		img='<img src="images/equal.png"></img>';
	}
	else if (total<lastTotal) {
		img='<img src="images/down.png"></img>';
	}
	else {
		img='<img src="images/up.png"></img>';
	}

	var monthtxt=addLeadingZeros(parseInt(lastMonth),2) + ". " + $.i18n($.monthNames[lastMonth-1]) + " ";
	monthtxt+='<img src="images/next.png" onclick="ShowP1MonthReportGas(' + lastMonth +',' + actYear + ')">';

	var addId = oTable.fnAddData([
		  monthtxt,
		  total.toFixed(3),
		  rcost.toFixed(2),
		  img
		], false);
	return total;
}

function ShowP1YearReportGas(actYear)
{
	if (actYear==0) {
		actYear=$.actYear;
	}
	else {
		$.actYear=actYear;
	}
  var htmlcontent = '';
  htmlcontent+=$('#toptextyeargas').html();
  htmlcontent+=$('#yearreportviewgas').html();
  
  $($.content).html(htmlcontent);
  $($.content + ' #backbutton').click( function( e ) {
	eval($.backfunction)();
  });
  $($.content).i18n();

  $($.content + ' #theader').html($.i18n("Usage") + " "+actYear);

	if ($.devSwitchType==0) {
		//Electra
		$($.content + ' #munit').html("kWh");
	}
	else {
		//Gas
		$($.content + ' #munit').html("m3");
	}

	$($.content + ' #comboyear').val(actYear);
	
	$($.content + ' #comboyear').change(function() { 
		OnSelChangeYearP1ReportGas();
	});
	$($.content + ' #comboyear').keypress(function() {
	  $(this).change();
	});

  $($.content + ' #yearreport').dataTable( {
		"sDom": '<"H"rC>t<"F">',
		"oTableTools": {
			"sRowSelect": "single"
		},
		"aaSorting": [[ 0, "asc" ]],
		"aoColumnDefs": [
			{ "bSortable": false, "aTargets": [ 3 ] }
		],
		"bSortClasses": false,
		"bProcessing": true,
		"bStateSave": false,
		"bJQueryUI": true,
		"aLengthMenu": [[50, 100, -1], [50, 100, "All"]],
		"iDisplayLength" : 50
  });

  var mTable = $($.content + ' #yearreport');
  var oTable = mTable.dataTable();
  //some test data
  oTable.fnClearTable();
  
  var total=0;
  var global=0;
  
	$.getJSON("json.htm?type=graph&sensor=counter&idx="+$.devIdx+"&range=year&actyear="+actYear,
	function(data) {
		var lastTotal=-1;
		var lastMonth=-1;
		
	    $.each(data.result, function(i,item)
		{
			var month=parseInt(item.d.substring(5, 7), 10);
			var year=parseInt(item.d.substring(0, 4), 10);
			if (year==actYear) {
				if (lastMonth==-1) {
					lastMonth=month;
				}
				if (lastMonth!=month)
				{
					//add totals to table
					lastTotal=Add2YearTableP1ReportGas(oTable,total,lastTotal,lastMonth,actYear);
					
					lastMonth=month;
					global+=total;

					total=0;
				}
				var day=parseInt(item.d.substring(8, 10), 10);
				var Usage=0;

				Usage=parseFloat(item.v);
				total+=Usage;
			}
		});

	//add last month
	if (total!=0) {
		lastTotal=Add2YearTableP1ReportGas(oTable,total,lastTotal,lastMonth,actYear);
		global+=lastTotal;
	}

	$($.content + ' #tu').html(global.toFixed(3));
	var montlycosts=0;
	if ($.devSwitchType==0) {
		//Electra
		montlycosts=(global*$.costsT1);
	}
	else {
		//Gas
		montlycosts=(global*$.costsGas);
	}
	
	$($.content + ' #mc').html(montlycosts.toFixed(2));
	  
	mTable.fnDraw();
		/* Add a click handler to the rows - this could be used as a callback */
		$($.content + ' #yearreport tbody tr').click( function( e ) {
			if ( $(this).hasClass('row_selected') ) {
				$(this).removeClass('row_selected');
			}
			else {
				oTable.$('tr.row_selected').removeClass('row_selected');
				$(this).addClass('row_selected');
			}
		});  
	});

  return false;
}

function ShowP1MonthReport(actMonth,actYear)
{
  var htmlcontent = '';

  htmlcontent+=$('#toptextmonth').html();
  htmlcontent+=$('#monthreportview').html();
  $($.content).html(htmlcontent);
  $($.content).i18n();

  $($.content + ' #theader').html($.i18n("Usage")+ " "+ $.i18n($.monthNames[actMonth-1])+" " + actYear);

  $($.content + ' #monthreport').dataTable( {
		"sDom": '<"H"rC>t<"F">',
		"oTableTools": {
			"sRowSelect": "single"
		},
		"aaSorting": [[ 0, "asc" ]],
		"aoColumnDefs": [
			{ "bSortable": false, "aTargets": [ 10 ] }
		],
		"bSortClasses": false,
		"bProcessing": true,
		"bStateSave": false,
		"bJQueryUI": true,
		"aLengthMenu": [[50, 100, -1], [50, 100, "All"]],
		"iDisplayLength" : 50
  });
  var mTable = $($.content + ' #monthreport');
  var oTable = mTable.dataTable();
  //some test data
  oTable.fnClearTable();
  
  var totalT1=0;
  var totalT2=0;
  var totalR1=0;
  var totalR2=0;
  
	$.getJSON("json.htm?type=graph&sensor=counter&idx="+$.devIdx+"&range=year&actmonth="+actMonth+"&actyear="+actYear,
	function(data) {
		var bHaveDelivered=(typeof data.delivered!= 'undefined');
		if (bHaveDelivered==false) {
			$($.content + ' #dreturn').hide();
		}
		else {
			$($.content + ' #dreturn').show();
		}
		oTable.fnSetColumnVis( 5, bHaveDelivered);
		oTable.fnSetColumnVis( 6, bHaveDelivered);
		oTable.fnSetColumnVis( 7, bHaveDelivered);
		oTable.fnSetColumnVis( 8, bHaveDelivered);
	
		var lastTotal=-1;
		
	    $.each(data.result, function(i,item)
		{
			var month=parseInt(item.d.substring(5, 7), 10);
			var year=parseInt(item.d.substring(0, 4), 10);

			if ((month==actMonth)&&(year==actYear)) {
				var day=parseInt(item.d.substring(8, 10), 10);
				var UsageT1=0;
				var UsageT2=0;
				var ReturnT1=0;
				var ReturnT2=0;

				UsageT1=parseFloat(item.v);
				if (typeof item.v2!= 'undefined') {
					UsageT2=parseFloat(item.v2);
				}
				if (typeof item.r1!= 'undefined') {
					ReturnT1=parseFloat(item.r1);
				}
				if (typeof item.r2!= 'undefined') {
					ReturnT2=parseFloat(item.r2);
				}
			
				totalT1+=UsageT1;
				totalT2+=UsageT2;
				totalR1+=ReturnT1;
				totalR2+=ReturnT2;

				var rcostT1=UsageT1*$.costsT1;
				var rcostT2=UsageT2*$.costsT2;
				var rcostR1=-(ReturnT1*$.costsR1);
				var rcostR2=-(ReturnT2*$.costsR2);
				var rTotal=rcostT1+rcostT2+rcostR1+rcostR2;

				var textR1="";
				var textR2="";
				var textCostR1="";
				var textCostR2="";
				
				if (ReturnT1!=0) {
					textR1=ReturnT1.toFixed(3);
					textCostR1=rcostR1.toFixed(2);
				}
				if (ReturnT2!=0) {
					textR2=ReturnT2.toFixed(3);
					textCostR2=rcostR2.toFixed(2);
				}
				
				var img;
				if ((lastTotal==-1)||(lastTotal==rTotal)) {
					img='<img src="images/equal.png"></img>';
				}
				else if (rTotal<lastTotal) {
					img='<img src="images/down.png"></img>';
				}
				else {
					img='<img src="images/up.png"></img>';
				}
				lastTotal=rTotal;

				var addId = oTable.fnAddData([
					  day,
					  UsageT1.toFixed(3),
					  rcostT1.toFixed(2),
					  UsageT2.toFixed(3),
					  rcostT2.toFixed(2),
					  textR1,
					  textCostR1,
					  textR2,
					  textCostR2,
					  rTotal.toFixed(2),
					  img
					], false);
			}
		});

	  $($.content + ' #tut1').html(totalT1.toFixed(3));
	  $($.content + ' #tut2').html(totalT2.toFixed(3));
	  $($.content + ' #trt1').html(totalR1.toFixed(3));
	  $($.content + ' #trt2').html(totalR2.toFixed(3));
	  
	  var gtotal=totalT1+totalT2;
	  var greturn=totalR1+totalR2;
	  $($.content + ' #tu').html(gtotal.toFixed(3));
	  $($.content + ' #tr').html(greturn.toFixed(3));
	  var montlycosts=(totalT1*$.costsT1)+(totalT2*$.costsT2)-(totalR1*$.costsR1)-(totalR2*$.costsR2);
	  $($.content + ' #mc').html(montlycosts.toFixed(2));
	  
	  mTable.fnDraw();
		/* Add a click handler to the rows - this could be used as a callback */
		$($.content + ' #monthreport tbody tr').click( function( e ) {
			if ( $(this).hasClass('row_selected') ) {
				$(this).removeClass('row_selected');
			}
			else {
				oTable.$('tr.row_selected').removeClass('row_selected');
				$(this).addClass('row_selected');
			}
		});  
	});

  return false;
}

function OnSelChangeYearP1Report()
{
	var yearidx=$($.content + ' #comboyear option:selected').val();
	if (typeof yearidx == 'undefined') {
		return ;
	}
	ShowP1YearReport(yearidx);
}

function Add2YearTableP1Report(oTable,totalT1,totalT2,totalR1,totalR2,lastTotal,lastMonth,actYear)
{
	var rcostT1=totalT1*$.costsT1;
	var rcostT2=totalT2*$.costsT2;
	var rcostR1=-(totalR1*$.costsR1);
	var rcostR2=-(totalR2*$.costsR2);
	var rTotal=rcostT1+rcostT2+rcostR1+rcostR2;

	var textR1="";
	var textR2="";
	var textCostR1="";
	var textCostR2="";

	if (totalR1!=0) {
		textR1=totalR1.toFixed(3);
		textCostR1=rcostR1.toFixed(2);
	}
	if (totalR2!=0) {
		textR2=totalR2.toFixed(3);
		textCostR2=rcostR2.toFixed(2);
	}

	
	var img;
	if ((lastTotal==-1)||(lastTotal==rTotal)) {
		img='<img src="images/equal.png"></img>';
	}
	else if (rTotal<lastTotal) {
		img='<img src="images/down.png"></img>';
	}
	else {
		img='<img src="images/up.png"></img>';
	}

	var monthtxt=addLeadingZeros(parseInt(lastMonth),2) + ". " + $.i18n($.monthNames[lastMonth-1]) + " ";
	monthtxt+='<img src="images/next.png" onclick="ShowP1MonthReport(' + lastMonth +',' + actYear + ')">';

	var addId = oTable.fnAddData([
		  monthtxt,
		  totalT1.toFixed(3),
		  rcostT1.toFixed(2),
		  totalT2.toFixed(3),
		  rcostT2.toFixed(2),
		  textR1,
		  textCostR1,
		  textR2,
		  textCostR2,
		  rTotal.toFixed(2),
		  img
		], false);
	return rTotal;
}

function ShowP1YearReport(actYear)
{
	if (actYear==0) {
		actYear=$.actYear;
	}
	else {
		$.actYear=actYear;
	}
  var htmlcontent = '';
  htmlcontent+=$('#toptextyear').html();
  htmlcontent+=$('#yearreportview').html();
  
  $($.content).html(htmlcontent);
  $($.content + ' #backbutton').click( function( e ) {
	eval($.backfunction)();
  });
  $($.content).i18n();
  
  $($.content + ' #theader').html($.i18n("Usage") + " "+actYear);

	$($.content + ' #comboyear').val(actYear);
	
	$($.content + ' #comboyear').change(function() { 
		OnSelChangeYearP1Report();
	});
	$($.content + ' #comboyear').keypress(function() {
	  $(this).change();
	});

  $($.content + ' #yearreport').dataTable( {
		"sDom": '<"H"rC>t<"F">',
		"oTableTools": {
			"sRowSelect": "single"
		},
		"aaSorting": [[ 0, "asc" ]],
		"aoColumnDefs": [
			{ "bSortable": false, "aTargets": [ 10 ] }
		],
		"bSortClasses": false,
		"bProcessing": true,
		"bStateSave": false,
		"bJQueryUI": true,
		"aLengthMenu": [[50, 100, -1], [50, 100, "All"]],
		"iDisplayLength" : 50
  });
  var mTable = $($.content + ' #yearreport');
  var oTable = mTable.dataTable();

  oTable.fnClearTable();
  
  var totalT1=0;
  var totalT2=0;
  var totalR1=0;
  var totalR2=0;

  var globalT1=0;
  var globalT2=0;
  var globalR1=0;
  var globalR2=0;
  
	$.getJSON("json.htm?type=graph&sensor=counter&idx="+$.devIdx+"&range=year&actyear="+actYear,
	function(data) {
		var bHaveDelivered=(typeof data.delivered!= 'undefined');
		if (bHaveDelivered==false) {
			$($.content + ' #dreturn').hide();
		}
		else {
			$($.content + ' #dreturn').show();
		}
		oTable.fnSetColumnVis( 5, bHaveDelivered);
		oTable.fnSetColumnVis( 6, bHaveDelivered);
		oTable.fnSetColumnVis( 7, bHaveDelivered);
		oTable.fnSetColumnVis( 8, bHaveDelivered);
	
		var lastTotal=-1;
		var lastMonth=-1;
		
	    $.each(data.result, function(i,item)
		{
			var month=parseInt(item.d.substring(5, 7), 10);
			var year=parseInt(item.d.substring(0, 4), 10);

			if (year==actYear) {
				if (lastMonth==-1) {
					lastMonth=month;
				}
				if (lastMonth!=month)
				{
					//add totals to table
					lastTotal=Add2YearTableP1Report(oTable,totalT1,totalT2,totalR1,totalR2,lastTotal,lastMonth,actYear);
					
					lastMonth=month;
					globalT1+=totalT1;
					globalT2+=totalT2;
					globalR1+=totalR1;
					globalR2+=totalR2;

					totalT1=0;
					totalT2=0;
					totalR1=0;
					totalR2=0;
				}
				var day=parseInt(item.d.substring(8, 10), 10);
				var UsageT1=0;
				var UsageT2=0;
				var ReturnT1=0;
				var ReturnT2=0;

				UsageT1=parseFloat(item.v);
				if (typeof item.v2!= 'undefined') {
					UsageT2=parseFloat(item.v2);
				}
				if (typeof item.r1!= 'undefined') {
					ReturnT1=parseFloat(item.r1);
				}
				if (typeof item.r2!= 'undefined') {
					ReturnT2=parseFloat(item.r2);
				}
			
				totalT1+=UsageT1;
				totalT2+=UsageT2;
				totalR1+=ReturnT1;
				totalR2+=ReturnT2;
			}
		});

	//add last month
	if ((totalT1!=0)||(totalT2!=0)||(totalR1!=0)||(totalR2!=0)) {
		lastTotal=Add2YearTableP1Report(oTable,totalT1,totalT2,totalR1,totalR2,lastTotal,lastMonth,actYear);
		globalT1+=totalT1;
		globalT2+=totalT2;
		globalR1+=totalR1;
		globalR2+=totalR2;
	}

	$($.content + ' #tut1').html(globalT1.toFixed(3));
	  $($.content + ' #tut2').html(globalT2.toFixed(3));
	  $($.content + ' #trt1').html(globalR1.toFixed(3));
	  $($.content + ' #trt2').html(globalR2.toFixed(3));

	  $($.content + ' #cntrt1').html($.CounterT1.toFixed(3));
	  $($.content + ' #cntrt2').html($.CounterT2.toFixed(3));
	  $($.content + ' #cntrr1').html($.CounterR1.toFixed(3));
	  $($.content + ' #cntrr2').html($.CounterR2.toFixed(3));
	  
	  var gtotal=globalT1+globalT2;
	  var greturn=globalR1+globalR2;
	  $($.content + ' #tu').html(gtotal.toFixed(3));
	  $($.content + ' #tr').html(greturn.toFixed(3));
	  var montlycosts=(globalT1*$.costsT1)+(globalT2*$.costsT2)-(globalR1*$.costsR1)-(globalR2*$.costsR2);
	  $($.content + ' #mc').html(montlycosts.toFixed(2));
	  
	  mTable.fnDraw();
		/* Add a click handler to the rows - this could be used as a callback */
		$($.content + ' #tbody tr').click( function( e ) {
			if ( $(this).hasClass('row_selected') ) {
				$(this).removeClass('row_selected');
			}
			else {
				oTable.$('tr.row_selected').removeClass('row_selected');
				$(this).addClass('row_selected');
			}
		});  
	});

  return false;
}

function ShowCounterLog(contentdiv,backfunction,id,name,switchtype)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  $.devSwitchType=switchtype;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p>\n';
  htmlcontent+=$('#dayweekmonthyearlog').html();

  if ((switchtype==0)||(switchtype==1)) {
	$.costsT1=0.2389;
	$.costsT2=0.2389;
	$.costsGas=0.6218;

	$.ajax({
		 url: "json.htm?type=command&param=getelectragascosts&idx="+$.devIdx,
		 async: false, 
		 dataType: 'json',
		 success: function(data) {
			$.costsT1=parseFloat(data.CostEnergy)/10000;
			$.costsT2=parseFloat(data.CostEnergyT2)/10000;
			$.costsGas=parseFloat(data.CostGas)/10000;
		 }
	});

	$.costsR1=$.costsT1;
	$.costsR2=$.costsT2;

	$.monthNames = [ "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December" ];
    
	var d = new Date();
	var actMonth = d.getMonth()+1;
	var actYear = d.getYear()+1900;
	$($.content).html(GetBackbuttonHTMLTableWithRight(backfunction,'ShowP1YearReportGas('+actYear+')',$.i18n('Report'))+htmlcontent);
  }
  else {
	$($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
  }

  $($.content).i18n();
  
  $.DayChart = $($.content + ' #daygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'column',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=day",
                function(data) {
					AddDataToUtilityChart(data,$.DayChart,switchtype);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Usage') + ' ' + Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime',
            labels: {
							formatter: function() {
								return Highcharts.dateFormat("%H:%M", this.value);
							}
						}
        },
        yAxis: {
            title: {
                text: $.i18n('Energy') + ' (Watt)'
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
										var unit = {
																'Usage': 'Watt',
																'Return': 'kWh',
																'Gas': 'm3',
																'Water': 'm3'
													}[this.series.name];
                    return $.i18n(Highcharts.dateFormat('%A',this.x)) + ' ' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) + '<br/>' + this.series.name + ': ' + this.y + ' ' + unit;
            }
        },
        plotOptions: {
            column: {
                minPointLength: 4,
                pointPadding: 0.1,
                groupPadding: 0
            }
        },
        legend: {
            enabled: false
        }
    });
  
  $.WeekChart = $($.content + ' #weekgraph');
  $.WeekChart.highcharts({
      chart: {
          type: 'column',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=week",
                function(data) {
					AddDataToUtilityChart(data,$.WeekChart,switchtype);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Last Week')
        },
        xAxis: {
            type: 'datetime',
            dateTimeLabelFormats: {
                day: '%a'
            },
            tickInterval: 24 * 3600 * 1000
        },
        yAxis: {
            min: 0,
            maxPadding: 0.2,
            endOnTick: false,
            title: {
                text: $.i18n('Energy') + ' (kWh)'
            }
        },
        tooltip: {
            formatter: function() {
										var unit = {
																'Usage': 'kWh',
																'Return': 'kWh',
																'Gas': 'm3',
																'Water': 'm3'
													}[this.series.name];
                    return $.i18n(Highcharts.dateFormat('%A',this.x)) + ' ' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) + '<br/>' + this.series.name + ': ' + this.y + ' ' + unit;
            }
        },
        plotOptions: {
            column: {
                minPointLength: 4,
                pointPadding: 0.1,
                groupPadding: 0,
				dataLabels: {
                        enabled: true,
                        color: 'white'
                }
            }
        },
        legend: {
            enabled: false
        }
    });

  $.MonthChart = $($.content + ' #monthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          marginRight: 10,
          zoomType: 'xy',
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=month",
                function(data) {
					AddDataToUtilityChart(data,$.MonthChart,switchtype);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Usage')
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
										var unit = {
																'Usage': 'kWh',
																'Total_Usage': 'kWh',
																'Return': 'kWh',
																'Gas': 'm3',
																'Water': 'm3'
													}[this.series.name];
                    return $.i18n(Highcharts.dateFormat('%A',this.x)) + ' ' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) + '<br/>' + this.series.name + ': ' + this.y + ' ' + unit;
            }
        },
        plotOptions: {
			series: {
				point: {
					events: {
						click: function(event) {
							chartPointClickNewEx(event,false,ShowCounterLog);
						}
					}
				}
			},
			spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        legend: {
            enabled: false
        }
    });

  $.YearChart = $($.content + ' #yeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          marginRight: 10,
          zoomType: 'xy',
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=year",
                function(data) {
					AddDataToUtilityChart(data,$.YearChart,switchtype);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Usage')
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
										var unit = {
																'Usage': 'kWh',
																'Total_Usage': 'kWh',
																'Return': 'kWh',
																'Gas': 'm3',
																'Water': 'm3'
													}[this.series.name];
                    return $.i18n(Highcharts.dateFormat('%A',this.x)) + ' ' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) + '<br/>' + this.series.name + ': ' + this.y + ' ' + unit;
            }
        },
        plotOptions: {
			series: {
				point: {
					events: {
						click: function(event) {
							chartPointClickNewEx(event,false,ShowCounterLog);
						}
					}
				}
			},
			spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        legend: {
            enabled: false
        }
    });
}

function ShowUsageLog(contentdiv,backfunction,id,name)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p>\n';
  htmlcontent+=$('#daymonthyearlog').html();
  $($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
  $($.content).i18n();

  $.DayChart = $($.content + ' #daygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=day",
                function(data) {
                      var series = $.DayChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetUTCFromString(item.d), parseFloat(item.u) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Usage') + ' '  + Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Usage') + ' (Watt)'
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' Watt';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: $.i18n('Usage'),
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,true,ShowUsageLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.MonthChart = $($.content + ' #monthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=month",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseFloat(item.u_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseFloat(item.u_max) ] );
                      });
                      var series1 = $.MonthChart.highcharts().series[0];
                      var series2 = $.MonthChart.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Usage') + ' ' + $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Usage') + ' (Watt)'
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' Watt';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'Usage_min',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowUsageLog);
					}
				}
			}
		}, {
            name: 'Usage_max',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowUsageLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.YearChart = $($.content + ' #yeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=year",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseFloat(item.u_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseFloat(item.u_max) ] );
                      });
                      var series1 = $.YearChart.highcharts().series[0];
                      var series2 = $.YearChart.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Usage') + ' ' + $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: $.i18n('Usage') + ' (Watt)'
            },
            min: 0
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' Watt';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'Usage_min',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowUsageLog);
					}
				}
			}
		}, {
            name: 'Usage_max',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowUsageLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });
}

function ShowLuxLog(contentdiv,backfunction,id,name)
{
	clearInterval($.myglobals.refreshTimer);
  $('#modal').show();
  $.content=contentdiv;
  $.backfunction=backfunction;
  $.devIdx=id;
  $.devName=name;
  var htmlcontent = '';
  htmlcontent='<p><center><h2>' + name + '</h2></center></p>\n';
  htmlcontent+=$('#daymonthyearlog').html();
  $($.content).html(GetBackbuttonHTMLTable(backfunction)+htmlcontent);
  $($.content).i18n();

  $.DayChart = $($.content + ' #daygraph');
  $.DayChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=day",
                function(data) {
                      var series = $.DayChart.highcharts().series[0];
                      var datatable = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable.push( [GetUTCFromString(item.d), parseInt(item.lux) ] );
                      });
                      series.setData(datatable);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Lux') + ' '  + Get5MinuteHistoryDaysGraphTitle()
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'Lux'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' Lux';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'lux',
			events: {
				click: function(event) {
					chartPointClickNew(event,true,ShowLuxLog);
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.MonthChart = $($.content + ' #monthgraph');
  $.MonthChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=month",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseInt(item.lux_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseInt(item.lux_max) ] );
                      });
                      var series1 = $.MonthChart.highcharts().series[0];
                      var series2 = $.MonthChart.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Lux') + ' ' + $.i18n('Last Month')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'Lux'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' Lux';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'lux_min',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowLuxLog);
					}
				}
			}
		}, {
            name: 'lux_max',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowLuxLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });

  $.YearChart = $($.content + ' #yeargraph');
  $.YearChart.highcharts({
      chart: {
          type: 'spline',
          zoomType: 'xy',
          marginRight: 10,
          events: {
              load: function() {
                  
                $.getJSON("json.htm?type=graph&sensor=counter&idx="+id+"&range=year",
                function(data) {
                      var datatable1 = [];
                      var datatable2 = [];
                      
                      $.each(data.result, function(i,item)
                      {
                        datatable1.push( [GetDateFromString(item.d), parseInt(item.lux_min) ] );
                        datatable2.push( [GetDateFromString(item.d), parseInt(item.lux_max) ] );
                      });
                      var series1 = $.YearChart.highcharts().series[0];
                      var series2 = $.YearChart.highcharts().series[1];
                      series1.setData(datatable1);
                      series2.setData(datatable2);
                });
              }
          }
        },
       credits: {
          enabled: true,
          href: "http://www.domoticz.com",
          text: "Domoticz.com"
        },
        title: {
            text: $.i18n('Lux') + ' ' + $.i18n('Last Year')
        },
        xAxis: {
            type: 'datetime'
        },
        yAxis: {
            title: {
                text: 'Lux'
            },
            min: 0,
            minorGridLineWidth: 0,
            gridLineWidth: 0,
            alternateGridColor: null
        },
        tooltip: {
            formatter: function() {
                    return ''+
                    $.i18n(Highcharts.dateFormat('%A',this.x)) + '<br/>' + Highcharts.dateFormat('%Y-%m-%d %H:%M', this.x) +': '+ this.y +' Lux';
            }
        },
        plotOptions: {
            spline: {
                lineWidth: 3,
                states: {
                    hover: {
                        lineWidth: 3
                    }
                },
                marker: {
                    enabled: false,
                    states: {
                        hover: {
                            enabled: true,
                            symbol: 'circle',
                            radius: 5,
                            lineWidth: 1
                        }
                    }
                }
            }
        },
        series: [{
            name: 'lux_min',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowLuxLog);
					}
				}
			}
		}, {
            name: 'lux_max',
			point: {
				events: {
					click: function(event) {
						chartPointClickNew(event,false,ShowLuxLog);
					}
				}
			}
        }]
        ,
        navigation: {
            menuItemStyle: {
                fontSize: '10px'
            }
        }
    });
}

