function makeSVGnode(tag, attrs, text) {
	var el= document.createElementNS('http://www.w3.org/2000/svg', tag);
	for (var k in attrs)
		if(k=="xlink:href") el.setAttributeNS('http://www.w3.org/1999/xlink', 'href', attrs[k]);
		else el.setAttribute(k, attrs[k]);
	if (text.length != 0) el.appendChild(document.createTextNode(text));
	return el;
}

function createSVGmultiline(text) {
	var words = text.split(' ');                        
	var text_element = svgDocument.getElementById('multiline-text');
	var tspan_element = document.createElementNS(svgNS, "tspan");   // Create first tspan element
	var text_node = svgDocument.createTextNode(words[0]);           // Create text in tspan element

	tspan_element.appendChild(text_node);                           // Add tspan element to DOM
	text_element.appendChild(tspan_element);                        // Add text to tspan element

	for(var i=1; i<words.length; i++)
	{
		var len = tspan_element.firstChild.data.length;             // Find number of letters in string
		tspan_element.firstChild.data += " " + words[i];            // Add next word

		if (tspan_element.getComputedTextLength() > width)
		{
			tspan_element.firstChild.data = tspan_element.firstChild.data.slice(0, len);    // Remove added word

			var tspan_element = document.createElementNS(svgNS, "tspan");       // Create new tspan element
			tspan_element.setAttributeNS(null, "x", 10);
			tspan_element.setAttributeNS(null, "dy", 18);
			text_node = svgDocument.createTextNode(words[i]);
			tspan_element.appendChild(text_node);
			text_element.appendChild(tspan_element);
		}
	}
}
	
// reference:  http://phrogz.net/JS/classes/OOPinJS.html , http://phrogz.net/JS/classes/OOPinJS2.html
Function.prototype.inheritsFrom = function( parentClassOrObject ){ 
	if ( parentClassOrObject.constructor == Function ) 
	{ 
		//Normal Inheritance 
		this.prototype = new parentClassOrObject;
		this.prototype.constructor = this;
		this.prototype.parent = parentClassOrObject.prototype;
	} 
	else 
	{ 
		//Pure Virtual Inheritance 
		this.prototype = parentClassOrObject;
		this.prototype.constructor = this;
		this.prototype.parent = parentClassOrObject;
	} 
	return this;
}

function Device (item) {
	
	if (arguments.length != 0) {
		this.index = item.idx;
		this.xoffset = item.XOffset;
		this.yoffset = item.YOffset;
		this.width = 250;
		this.height = 75;
		this.type = item.Type;
		this.subtype = item.SubType;
		this.status = (item.Status == undefined) ? '' : item.Status;
		this.lastupdate = item.LastUpdate;
		this.protected = item.Protected;
		this.name = item.Name;
		this.image = "images/unknown.png";
		this.favorite = item.Favorite;
		this.batteryLevel = item.BatteryLevel;
		this.haveTimeout = item.HaveTimeout;
		this.data = item.Data;
		if (item.Usage != undefined) {
			this.data = item.Usage;
		}
		this.uniquename = item.Type.replace(/\s+/g, '') + this.index
		this.controlable = false;
		this.switchTypeVal = '';
		if (item.SwitchTypeVal != undefined) {
			this.switchTypeVal = item.SwitchTypeVal;
		}
		this.onClick = '';
		this.moveable = false;
		this.item = item;

		Device.count++;
		if ((this.xoffset == 0) && (this.yoffset == 0))  {
			this.yoffset += Device.notPositioned * 75;
			Device.notPositioned++;
		}
	}

	this.setDraggable = function(draggable) {
		this.moveable = draggable;
	}
    this.drawIcon = function(parent) {
		var el;
		if (Device.useSVGtags == true) {
			el = makeSVGnode('image', { id: this.uniquename + "_Icon", 
										'class': 'DeviceIcon', 
										'xlink:href': this.image, 
										width:'40', height:'40',
										onmouseover: (this.moveable == true) ? '' : "$('.DeviceDetails').css('display','none'); document.getElementById('"+this.uniquename+"_Detail').style.display='inline';",
										onmousedown: (this.moveable == true) ? "DragStart(evt);" : '',
										onmouseup: (this.moveable == true) ? "DragEnd(evt);" : '',
										onclick: (this.moveable == true) ? '' : "$('.DeviceDetails').css('display','none'); document.getElementById('"+this.uniquename+"_Detail').style.display='inline';",
										style: (this.moveable == true) ? 'cursor:move;' : 'cursor:hand;' }, '');
			el.appendChild(makeSVGnode('title', null, this.name));
		} else {
			el = makeSVGnode('img', {	id: this.uniquename + "_Icon", 
										'src': this.image, 
										alt: this.name,
										width:'40', height:'40', 
										onmouseover: (this.moveable == true) ? '' : "document.getElementById('"+this.uniquename+"_Detail').style.display='inline';",
										onmousedown: (this.moveable == true) ? "DragStart(evt);" : '',
										onmouseup: (this.moveable == true) ? "DragEnd(evt);" : '',
										onclick: (this.moveable == true) ? '' : "document.getElementById('"+this.uniquename+"_Detail').style.display='inline';",
										style: (this.moveable == true) ? 'cursor:move;' : 'cursor:hand;' }, '');
		}
		
		var existing = document.getElementById(this.uniquename + "_Icon");
		if (existing != undefined) {
			existing.parentNode.replaceChild(el, existing);
		} else {
			parent.appendChild(el);
		}
		return el;
	}
    this.drawDetails = function(parent, display) {
		var nbackcolor="#D4E1EE";
		var showme = (display == false) ? 'none' : 'inline';
		if (this.protected == true) {
			nbackcolor="#A4B1EE";
		}
		if (this.haveTimeout == true) {
			nbackcolor="#DF2D3A";
		}
		if (this.batteryLevel <= 10) {
			nbackcolor="#DDDF2D";
		}
		var existing = document.getElementById(this.uniquename + "_Detail");
		var el;
		if (Device.useSVGtags == true) {
			if (existing != undefined) {
				el = existing.cloneNode(false);  // shallow clone only
			} else {
				el = makeSVGnode('g', { 'class': 'DeviceDetails', id: this.uniquename+'_Detail', transform:'translate(-5,-30)', width: this.width, height: this.height, onmouseout:"this.style.display='" + showme + "';", style: 'display:' + showme + ';'}, '');
			}
			el.appendChild(makeSVGnode('rect', { 'class':'popup', rx:5, ry:5, width: this.width, height: this.height }, ''));
			el.appendChild(makeSVGnode('rect', { 'class':'header', x:5, y:5, rx:5, ry:5, width: (this.width-10), height:20, style: 'fill:'+nbackcolor }, ''));
			el.appendChild(makeSVGnode('text', {id: "name", x:10, y:20, 'text-anchor':'start' }, this.name));
			el.appendChild(makeSVGnode('text', {id: "bigtext", x: (this.width-10), y: 20, 'text-anchor':'end', 'font-weight':'bold' }, this.data));
			el.appendChild(makeSVGnode('image',{id: "image", x:5, y:30, 'xlink:href': this.image, width:'40', height:'40', onclick:(this.onClick.length != 0) ? this.onClick : '', onmouseover:(this.onClick.length != 0) ? "cursorhand()" : '',  onmouseout:(this.onClick.length != 0) ? "cursordefault()" : ''}, ''));
			var gText = makeSVGnode('g', { id: "textgroup", transform:'translate(50,30)' }, '');
			el.appendChild(gText);
			gText.appendChild(makeSVGnode('text', {id: "status", x:0, y:15, 'font-weight':'bold', 'font-size':'90%' }, this.status));
			gText.appendChild(makeSVGnode('text', {id: "lastseen", x:0, y:35, 'font-size':'80%', 'font-style':'italic' }, 'Last Seen: '));
			gText.appendChild(makeSVGnode('text', {id: "lastupdate", x:55, y:35, 'font-size':'80%' }, ' '+this.lastupdate ));
			gText.appendChild(makeSVGnode('image', {id: "favorite", x:(this.width-70), y:25, 'xlink:href': (this.favorite == 1) ? 'images/favorite.png' : 'images/nofavorite.png', width:'16', height:'16' }, '' ));
		}
		else {  // this is not used but is included to show that the code could draw other than SVG
			el = makeSVGnode('div', { 'class': 'span4 DeviceDetails', id: this.uniquename+'_Detail', style: 'display:' + showme + '; position:relative; '}, '');
			var table = makeSVGnode('table', { 'id': 'itemtablesmall', border:'0', cellspacing: '0', cellpadding: '0' }, '');
			el.appendChild(table);
			var tbody = makeSVGnode('tbody', { }, '');
			table.appendChild(tbody);
			var tr = makeSVGnode('tr', { }, '');
			tbody.appendChild(tr);
			tr.appendChild(makeSVGnode('td', {id: "name", style: "background-color: rgb(164,177,238);" }, this.name));
			tr.appendChild(makeSVGnode('td', {id: "bigtext" }, this.data));
			tr.appendChild(makeSVGnode('img',{id: "image",src: this.image, width:'40', height:'40' }, ''));
			tr.appendChild(makeSVGnode('td', {id: "status" }, this.status));
			tr.appendChild(makeSVGnode('span', {id: "lastseen", 'font-size':'80%', 'font-style':'italic' }, 'Last Seen: '));
			tr.appendChild(makeSVGnode('td', {id: "lastupdate" }, this.lastupdate));
		}
		
		if (existing != undefined) {
			existing.parentNode.replaceChild(el, existing);
		} else {
			parent.appendChild(el);
		}
		return el;
    }
    this.drawButtons = function() {
        return;
    }
    this.htmlMinimum = function(parent) {
		var mainEl;
		// store in page for later use
		if ($("#DeviceData")[0] != undefined) {
			var el = makeSVGnode('data', {id:this.uniquename+'_Data', item: JSON.stringify(this.item) }, '' );
			var existing = document.getElementById(this.uniquename+'_Data');
			if (existing != undefined) {
				$("#DeviceData")[0].replaceChild(el, existing);
			} else {
				$("#DeviceData")[0].appendChild(el);
			}
		}

		var mainEl = document.getElementById(this.uniquename);
		if (mainEl == undefined) {
			if (this.moveable == true) {
				mainEl = makeSVGnode('g', {  id:this.uniquename, transform:'translate(' + this.xoffset + ',' + this.yoffset + ')', idx:this.index, xoffset:this.xoffset, yoffset:this.yoffset }, '');
			} else {
				mainEl = makeSVGnode('g', {  id:this.uniquename, transform:'translate(' + this.xoffset + ',' + this.yoffset + ')' }, '');
			}
			this.drawIcon(mainEl);
			($("#DeviceIcons")[0] == undefined) ? parent.appendChild(mainEl) : $("#DeviceIcons")[0].appendChild(mainEl);;

			if (this.moveable == true) {
				mainEl = makeSVGnode('g', {  id:this.uniquename, transform:'translate(' + this.xoffset + ',' + this.yoffset + ')', idx:this.index, xoffset:this.xoffset, yoffset:this.yoffset }, '');
			} else {
				mainEl = makeSVGnode('g', {  id:this.uniquename, transform:'translate(' + this.xoffset + ',' + this.yoffset + ')' }, '');
			}
			this.drawDetails(mainEl, false);
			($("#DeviceIcons")[0] == undefined) ? parent.appendChild(mainEl) : $("#DeviceDetails")[0].appendChild(mainEl);;
		}
		else {
			this.drawIcon(mainEl);
			this.drawDetails(mainEl, false);
		}
		
		return mainEl;
    }
    this.htmlMedium = function() {
        return this.drawDetails();
    }
    this.htmlMaximum = function() {
        return this.drawDetails() + this.drawButtons();
    }
    this.htmlMobile = function() {
        return this.drawDetails();
    }
}
Device.count = 0;
Device.notPositioned = 0;
Device.useSVGtags = false;
Device.backFunction = '';
Device.contentTag = '';
Device.initialise = function() {
	Device.count = 0;
	Device.notPositioned = 0;
	if (Device.useSVGtags == true) {
		var cont = $("#svgcontainer")[0];
		if (cont != undefined) {
			var devCont;
			if ($("#DeviceContainer")[0] == undefined) {
				devCont = makeSVGnode('g', { id: 'DeviceContainer'}, '');
				cont.appendChild(devCont);
			}
			if ($("#DeviceData")[0] == undefined) {
				devCont.appendChild(makeSVGnode('g', { id: 'DeviceData'}, ''));
			}
			if ($("#DeviceIcons")[0] == undefined) {
				devCont.appendChild(makeSVGnode('g', { id: 'DeviceIcons'}, ''));
			}
			if ($("#DeviceDetails")[0] == undefined) {
				devCont.appendChild(makeSVGnode('g', { id: 'DeviceDetails'}, ''));
			}
		}
		// clean up existing data if it exists
		$("#DeviceData").empty();
		$("#DeviceDetails").empty();
		$("#DeviceIcons").empty();
	}
}
Device.create = function (item) {
	var dev;
	var type = item.TypeImg.toLowerCase();
	if (item.CustomImage != 0) {
		type = item.Image.toLowerCase()
	}
	
	switch (type) {
		case "contact":
			dev = new Contact(item);
			break;
		case "counter":
			dev = new Counter(item);
			break;
		case "current":
			dev = new Current(item);
			break;
		case "door":
			dev = new Door(item);
			break;
		case "fan":
			dev = new BinarySwitch(item);
			break;
		case "lightbulb":
			dev = new Lightbulb(item);
			break;
		case "lux":
			dev = new Sensor(item);
			break;
		case "motion":
			dev = new Motion(item);
			break;
		case "hardware":
			dev = new Hardware(item);
			break;
		case "push":
			dev = new Pushon(item);
			break;
		case "rain":
			dev = new Rain(item);
			break;
		case "temperature":
			dev = new Temperature(item);
			break;
		case "wind":
			dev = new Wind(item);
			break;
		default:
			if (item.SwitchType != 'undefined') {
				dev = new Switch(item);
			} else {
				dev = new Sensor(item);
			}
	}
	return dev;
}
Device.scale = function (attr) {
	if ($("#DeviceContainer")[0] != undefined) {
		$("#DeviceContainer")[0].setAttribute("transform", attr);
	}
	return;
}

function Sensor (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = "images/" + item.TypeImg + "48.png";
		this.onClick = "Show" + this.type + "Log('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
	}
}
Sensor.inheritsFrom ( Device );

function BinarySensor (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
	}
}
BinarySensor.inheritsFrom ( Sensor );

function SecuritySensor (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = (this.status == "On") ? "images/" + item.TypeImg + "48-on.png" : "images/" + item.TypeImg + "48-off.png";
	}
}
SecuritySensor.inheritsFrom ( BinarySensor );

function WeatherSensor (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
	}
}
WeatherSensor.inheritsFrom ( Sensor );

function Switch (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.controlable = true;
		if (item.CustomImage != 0) {
			this.image = (this.status == "On") ? "images/" + item.Image + "48_On.png" : "images/" + item.Image + "48_Off.png";
		} else {
			this.image = (this.status == "On") ? "images/" + item.TypeImg + "48_On.png" : "images/" + item.TypeImg + "48_Off.png";
		}
	}
}
Switch.inheritsFrom ( Sensor );

function BinarySwitch (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.onClick = "SwitchLight(" + this.index + ",'" + ((this.status == "On") ? "Off" : "On") + "', undefined, " + this.protected + ");";
		this.data = '';
	}
}
BinarySwitch.inheritsFrom ( Switch );


function Counter (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = "images/counter.png";
		this.onClick = "ShowCounterLog('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
		if (typeof item.CounterToday != 'undefined') {
			this.status += ' ' + $.i18n("Today") + ': ' + item.CounterToday;
		}
		if (typeof item.CounterDeliv != 'undefined') {
			if (item.CounterDeliv!=0) {
				if (item.UsageDeliv.charAt(0) != 0) {
					this.status += '-' + item.UsageDeliv;
				}
				this.status += ', ' + $.i18n("Return") + ': ' + item.CounterDelivToday;
			}
		}
	}
}
Counter.inheritsFrom ( Sensor );

function Contact (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = (this.status == "Closed") ? "images/contact48.png" : this.image = "images/contact48_open.png";
		this.data = '';
		this.onClick = "ShowLightLog('" + this.index + "','" + this.name + "','#" + Device.contentTag + "','" + Device.backFunction + "');";
	}
}
Contact.inheritsFrom ( BinarySensor );

function Current (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		switch (this.type) {
			case "Energy":
				this.onClick = "ShowCounterLogSpline('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
				break;
			case "Usage":
				this.onClick = "ShowUsageLog('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
				break;
			default:
				this.onClick = "ShowCurrentLog('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
		}
		this.status = '';
		if (typeof item.Usage != 'undefined') {
			this.status = (item.Usage != this.data) ? item.Usage : '';
		}
		if (typeof item.CounterToday != 'undefined') {
			this.status += ' ' + $.i18n("Today") + ': ' + item.CounterToday;
		}
		if (typeof item.CounterDeliv != 'undefined') {
			if (item.CounterDeliv!=0) {
				if (item.UsageDeliv.charAt(0) != 0) {
					this.status += '-' + item.UsageDeliv;
				}
				this.status += ', ' + $.i18n("Return") + ': ' + item.CounterDelivToday;
			}
		}
	}
}
Current.inheritsFrom ( Sensor );

function Door (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = (this.status == "Closed") ? "images/" + item.TypeImg + "48.png" : this.image = "images/" + item.TypeImg + "48open.png";
		this.data = '';
	}
}
Door.inheritsFrom ( BinarySwitch );

function Hardware (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.onClick = "Show" + this.subtype + "Log('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
		if (item.CustomImage == 0) 
			switch (item.SubType.toLowerCase()) {
				case "percentage":
					this.image = "images/Percentage48.png";
					break;
		}
	}
}
Hardware.inheritsFrom ( Sensor );

function Lightbulb (item) {
	if (arguments.length != 0) {
		item.TypeImg = "Light";
		this.parent.constructor (item);
	}
}
Lightbulb.inheritsFrom ( BinarySwitch );

function Motion (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = (this.status == "On") ? "images/" + item.TypeImg + "48-on.png" : "images/" + item.TypeImg + "48-off.png";
		this.onClick = "ShowLightLog('" + this.index + "','" + this.name + "','#" + Device.contentTag + "','" + Device.backFunction + "');";
		this.data = '';
	}
}
Motion.inheritsFrom ( SecuritySensor );

function Pushon (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = (this.status == "On") ? "images/" + item.TypeImg + "on48.png" : "images/" + item.TypeImg + "48.png";
	}
}
Pushon.inheritsFrom ( BinarySwitch );

function Rain (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		if (typeof item.Rain != 'undefined') {
			this.status = item.Rain + ' mm';
			this.data = this.status;
			if (typeof item.RainRate != 'undefined') {
				if (item.RainRate != 0) {
					this.status += ', Rate: ' + item.RainRate + ' mm/h';
				}
			}
		}
	}
}
Rain.inheritsFrom ( WeatherSensor );

function Temperature (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.onClick = "ShowTempLog('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
		if (typeof item.Temp != 'undefined') {
			this.image = "images/" + GetTemp48Item(item.Temp);
			this.status = $.i18n('Temp') + ': ' + item.Temp + $.myglobals.tempsign;
			this.data = item.Temp + $.myglobals.tempsign;

			if (typeof item.Chill != 'undefined') {
				this.status += $.i18n('Chill') +': ' + item.Chill + $.myglobals.tempsign;
			}
		}
	}
}
Temperature.inheritsFrom ( Sensor );

function Wind (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		if (typeof item.DirectionStr != 'undefined') {
			this.image = "images/Wind" + item.DirectionStr + ".png";
			this.status = item.DirectionStr;
			this.data = item.DirectionStr;
			if (typeof item.Direction != 'undefined') {
				this.status = item.Direction + ' ' + item.DirectionStr;
			}
		}
		if (typeof item.Speed != 'undefined') {
			this.status += ', ' + item.Speed + ' ' + $.myglobals.windsign;
			this.data += ' / ' + item.Speed + ' ' + $.myglobals.windsign;
		}
		if (typeof item.Gust != 'undefined') {
			this.status += ', ' + $.i18n('Gust') + ': ' + item.Gust + ' ' + $.myglobals.windsign;
		}
	}
}
Wind.inheritsFrom ( WeatherSensor );
