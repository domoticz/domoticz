/*
//	(c)  Kendel Boul - 2014
*/

function makeSVGnode(tag, attrs, text, title) {
	var el = document.createElementNS('http://www.w3.org/2000/svg', tag);
	for (var k in attrs)
		if(k=="xlink:href") el.setAttributeNS('http://www.w3.org/1999/xlink', 'href', attrs[k]);
		else el.setAttribute(k, attrs[k]);
	if ((typeof text != 'undefined') && (text.length != 0)) el.appendChild(document.createTextNode(text));
	if ((typeof title != 'undefined') && (title.length != 0)) {
		var elTitle = document.createElementNS('http://www.w3.org/2000/svg', 'title');
		if (title.length != 0) elTitle.appendChild(document.createTextNode(title));
		el.appendChild(elTitle);
	}
	return el;
}

function makeSVGmultiline(attrs, text, title, maxX, minY, incY) {

	// no wrap parameters
	if ((typeof maxX == 'undefined') || (typeof minY == 'undefined') || (typeof incY == 'undefined')) {
		return makeSVGnode('text', attrs, text, title);
	}
	// no text to wrap
	if ((typeof text == 'undefined') || (text.length == 0)) {
		return makeSVGnode('text', attrs, text, title);
	}

	var svg = document.getElementsByTagName('svg')[0];
	var elText = makeSVGnode('text', attrs, '', title);
	svg.appendChild(elText);
	var elSpan = makeSVGnode('tspan', {}, text);
	elText.appendChild(elSpan);
	if (elSpan.getComputedTextLength() <= maxX)
	{
		return elText;
	}
	
	elText.setAttribute('y', minY);
	elSpan.firstChild.data = '';
	
	var phrase = text.split(', ');                        
	for(var i=0; i<phrase.length; i++)
	{
		var len = elSpan.firstChild.data.length;
		if (len != 0) {
			elSpan.firstChild.data += ", ";
		}
		elSpan.firstChild.data += phrase[i];

		if (elSpan.getComputedTextLength() > maxX)
		{
			elSpan.firstChild.data = elSpan.firstChild.data.slice(0, len);    // Remove added word
			elSpan = makeSVGnode('tspan', {}, text);
			elText.appendChild(elSpan);
			elSpan.setAttribute('x', 0);
			minY += incY;
			elSpan.setAttribute('y', minY);
			elSpan.firstChild.data = phrase[i];
		}
	}
	return elText;
}

function Transform (tag) {
	this.scale = 0;
	this.xOffset = 0;
	this.yOffset = 0;

	if (arguments.length != 0) {
		
		var sTransform;
		if (typeof tag == 'string') sTransform = tag;
		if (typeof tag == 'object') {
			if (tag instanceof SVGGElement) sTransform = tag.getAttribute('transform');
			if (tag[0] instanceof SVGGElement) sTransform = tag[0].getAttribute('transform');
			if ((typeof sTransform != 'undefined') && (sTransform != null) && (sTransform.length != 0)) {
				var aTransform = sTransform.split(/[,() ]/);
				var i;
				for (i=0; i < aTransform.length; i++) {
					if (aTransform[i].toLowerCase() == 'translate') {
						this.xOffset = parseInt(aTransform[++i]);
						this.yOffset = parseInt(aTransform[++i]);
					}
					if (aTransform[i].toLowerCase() == 'scale') {
						this.scale = parseFloat(aTransform[++i]);
					}
				}
			}
		}
	}

	this.Add = function(tag) {
		if (tag instanceof Transform) {
			this.scale += tag.scale;
			this.xOffset += tag.xOffset;
			this.yOffset += tag.yOffset;
		}
	};
	this.Calculate = function(oTarget) {
		try {
			var svg = document.getElementsByTagName('svg')[0];
			var oMatrix = oTarget.getTransformToElement(svg);  // sometimes throws errors on IE 11
			this.scale = (oMatrix.d == 1) ? 0 : oMatrix.d;
			this.xOffset = oMatrix.e;
			this.yOffset = oMatrix.f;
		}
		catch(err) {
			var oTemp = oTarget.parentNode;
			var oTransform = new Transform();
			while (oTemp.nodeName.toLowerCase() != 'svg') {
				var oNew = new Transform(oTemp);
				oTransform.Add(oNew);
				oTemp = oTemp.parentNode;
			}
			this.scale = oTransform.scale;
			this.xOffset = oTransform.xOffset;
			this.yOffset = oTransform.yOffset;
		}
	}
	this.toString = function() {
		var retVal = '';
		if ((this.xOffset+this.yOffset) != 0) {
			retVal = 'translate(' + this.xOffset + ',' + this.yOffset+')';
		}
		if (this.scale != 0) {
			retVal += ' scale(' + this.scale + ')';
		}
		return retVal;
	}
}

function Slider (event) {

	if (arguments.length == 0) {
		$('.SliderBack')
			.off()
			.bind('click', function(event, ui){ var oSlider = new Slider(event); oSlider.Click(event); });
		$('.Slider')
			.off()
			.bind('click', function(event, ui){ var oSlider = new Slider(event); oSlider.Click(event); });
		$('.SliderHandle')
			.off()
			.draggable()
			.bind('drag', function(event, ui){ var oSlider = new Slider(event); oSlider.Drag(event); })
			.bind('dragstop', function(event, ui){ var oSlider = new Slider(event); oSlider.Click(event); });
	}

	var localPoint;
	var xOffset;
	var oSliderBack;
	var oSlider;
	var oSliderHandle;
	var curLevel;
	var newLevel;
	var maxLevel;
	var handleWidth;
	var xMin;
	var xMax;
	
	this.Initialise = function(event) {
		var svg = document.getElementsByTagName('svg')[0];
		var pt = svg.createSVGPoint();
		pt.x = event.clientX;
		pt.y = event.clientY;
		localPoint = pt.matrixTransform(svg.getScreenCTM().inverse());
		var oTransform = new Transform();
		oTransform.Calculate(event.target);
		xOffset = localPoint.x - oTransform.xOffset;
		if (oTransform.scale != 0) xOffset /= oTransform.scale;

		var oGroup = event.target.parentNode;
		for (var i=0; i < oGroup.childNodes.length; i++) {
			if (oGroup.childNodes[i].id == "sliderback") {
				oSliderBack = oGroup.childNodes[i];
			}
			if (oGroup.childNodes[i].id == "slider") {
				oSlider = oGroup.childNodes[i];
			}
			if (oGroup.childNodes[i].id == "sliderhandle") {
				oSliderHandle = oGroup.childNodes[i];
			}
		}
		if (typeof oSliderHandle != undefined) {
			handleWidth = parseInt(oSliderHandle.getAttribute("width"));
			xMin = -(handleWidth/4);
			xMax = parseInt(oSliderHandle.getAttribute("xmax")) - (handleWidth/2);
			curLevel = parseInt(oSliderHandle.getAttribute("level"));
			maxLevel = parseInt(oSliderHandle.getAttribute("maxlevel"));
			xOffset -= (handleWidth/2);
			if (xOffset < xMin) xOffset = xMin;
			if (xOffset > xMax) xOffset = xMax;
			newLevel = Math.round(maxLevel * (xOffset / xMax));
			oSliderHandle.setAttribute("x", (xMax/maxLevel)*newLevel);
			oSlider.setAttribute("width", (xMax/maxLevel)*newLevel + (handleWidth/2));
		}
	};
	this.Click = function(event) {
		this.Initialise(event);
		if (newLevel != curLevel) {
			oSliderHandle.setAttribute("level", newLevel);
			var idx = parseInt(oSliderHandle.getAttribute("devindex"));
//			SetDimValue(idx, newLevel);  // this is synchronous and makes this quite slow
			if (window.my_config.userrights==0) {
				HideNotify();
				ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
				return;
			}
			$.ajax({
				 url: "json.htm?type=command&param=switchlight&idx=" + idx + "&switchcmd=Set%20Level&level=" + newLevel,
				 async: true, 
				 dataType: 'json'
			});
			eval(Device.switchFunction);
		}
	};
	this.Drag = function(event) {
		this.Initialise(event);
	};
}

function DoNothing() {
	return;
}

//  �2003 by Gavin Kistner:  http://phrogz.net/JS/classes/OOPinJS.html , http://phrogz.net/JS/classes/OOPinJS2.html
Function.prototype.inheritsFrom = function( parentClassOrObject ){ 
	if ( parentClassOrObject.constructor == Function ) 
	{ 
		//Normal Inheritance 
		this.prototype = new parentClassOrObject;
		this.prototype.constructor = this;
		this.prototype.parent = parentClassOrObject.prototype;
	} 
	else 
	{ 
		//Pure Virtual Inheritance 
		this.prototype = parentClassOrObject;
		this.prototype.constructor = this;
		this.prototype.parent = parentClassOrObject;
	} 
	return this;
}

function Device (item) {
	
	if (arguments.length != 0) {
		this.index = item.idx;
		this.planID = (typeof item.PlanID != 'undefined') ? parseInt(item.PlanID) : 0;
		this.xoffset = (typeof item.XOffset != 'undefined') ? parseInt(item.XOffset) : 0;
		this.yoffset = (typeof item.YOffset != 'undefined') ? parseInt(item.YOffset) : 0;
		this.width = Device.elementPadding*50;
		this.height = Device.elementPadding*15;
		this.type = item.Type;
		this.devSceneType = ((item.Type == 'Scene') || (item.Type == 'Group')) ? 1 : 0;
		this.subtype = item.SubType;
		this.status = (typeof item.Status == 'undefined') ? '' : item.Status;
		this.lastupdate = item.LastUpdate;
		this.protected = item.Protected;
		this.name = item.Name;
		this.imagetext = '';
		this.image = "images/unknown.png";
		this.image_opacity = 1;
		this.image2 = "";
		this.image2_opacity = 1;
		this.favorite = item.Favorite;
		this.batteryLevel = item.BatteryLevel;
		this.haveTimeout = item.HaveTimeout;
		this.haveDimmer = false;  // data from server is unreliable so iherting classes will need to force true
		this.level = (typeof item.LevelInt == 'undefined') ? 0 : parseInt(item.LevelInt);
		this.levelMax = (typeof item.MaxDimLevel == 'undefined') ? 0 : parseInt(item.MaxDimLevel);
		this.data = (typeof item.Data == 'undefined') ? '' : item.Data;
		if (typeof item.Usage != 'undefined') {
			this.data = item.Usage;
		}
		this.uniquename = item.Type.replace(/\s+/g, '') + '_' + this.planID + '_' + this.index;
		this.controlable = false;
		this.switchTypeVal = '';
		if (typeof item.SwitchTypeVal != 'undefined') {
			this.switchTypeVal = item.SwitchTypeVal;
		}
		this.onClick = '';
		this.onClick2 = '';
		this.moveable = false;

		// store in page for later use
		if ($("#DeviceData")[0] != undefined) {
			var el = makeSVGnode('data', {id:this.uniquename+'_Data', item: JSON.stringify(item) }, '' );
			var existing = document.getElementById(this.uniquename+'_Data');
			if (existing != undefined) {
				$("#DeviceData")[0].replaceChild(el, existing);
			} else {
				$("#DeviceData")[0].appendChild(el);
			}
		}

		Device.count++;
		if ((this.xoffset == 0) && (this.yoffset == 0))  {
			var iconSpacing = 75;
			var iconsPerColumn = Math.floor(Device.yImageSize / iconSpacing);
			this.yoffset += Device.notPositioned * iconSpacing;
			while ((this.yoffset+50) > Device.yImageSize) {
				this.xoffset += iconSpacing;
				this.yoffset -= (iconsPerColumn * iconSpacing);
			}
			Device.notPositioned++;
		}
	}

	this.setDraggable = function(draggable) {
		this.moveable = draggable;
	}
    this.drawIcon = function(parent) {
		var el;
		if (Device.useSVGtags == true) {
			el = makeSVGnode('image', { id: this.uniquename + "_Icon", 
										'class': 'DeviceIcon', 
										'xlink:href': this.image, 
										width:Device.iconSize, height:Device.iconSize,
										onmouseover: (this.moveable == true) ? '' : "Device.popup('"+this.uniquename+"');",
										onclick: (this.moveable == true) ? '' : "Device.popup('"+this.uniquename+"');",
										style: (this.moveable == true) ? 'cursor:move;' : 'cursor:hand;' }, '');
			el.appendChild(makeSVGnode('title', null, this.name));
		} else {
			el = makeSVGnode('img', {	id: this.uniquename + "_Icon", 
										'src': this.image, 
										alt: this.name,
										width:Device.iconSize, height:Device.iconSize, 
										onmouseover: (this.moveable == true) ? '' : "Device.popup('"+this.uniquename+"');",
										onclick: (this.moveable == true) ? '' : "Device.popup('"+this.uniquename+"');",
										style: (this.moveable == true) ? 'cursor:move;' : 'cursor:hand;' }, '');
		}
		
		var existing = document.getElementById(this.uniquename + "_Icon");
		if (existing != undefined) {
			existing.parentNode.replaceChild(el, existing);
		} else {
			parent.appendChild(el);
		}
		return el;
	}
    this.drawDetails = function(parent, display) {
		var nbackcolor="#D4E1EE";
		var showme = (display == false) ? 'none' : 'inline';
		if (this.protected == true) {
			nbackcolor="#A4B1EE";
		}
		if (this.haveTimeout == true) {
			nbackcolor="#DF2D3A";
		}
		if (this.batteryLevel <= 10) {
			nbackcolor="#DDDF2D";
		}
		var existing = document.getElementById(this.uniquename + "_Detail");
		var el;
		var sDirection = 'right';
		if (Device.useSVGtags == true) {
			if (existing != undefined) {
				el = existing.cloneNode(false);  // shallow clone only
				sDirection = el.getAttribute('direction');
				var oTransform = new Transform(el);
				if (sDirection == 'right') {
					oTransform.xOffset = -Device.elementPadding;
				} else {
					oTransform.xOffset = -(this.width - Device.iconSize - Device.elementPadding);
				}
				el.setAttribute('transform',oTransform.toString());
			} else {
				el = makeSVGnode('g', { 'class': 'DeviceDetails', id: this.uniquename+'_Detail', transform:'translate(-' + Device.elementPadding + ',-' + Device.elementPadding*6 + ')', width: this.width, height: this.height, direction:'right', style: 'display:' + showme + ';', onmouseleave: "$('.DeviceDetails').css('display', 'none');", 'pointer-events':'none' }, '');
			}
			el.appendChild(makeSVGnode('rect', { id: "shadow", transform:"translate(2,2)", rx:Device.elementPadding, ry:Device.elementPadding, width: this.width, height: this.height, 'stroke-width':'0', fill:'black', opacity: "0.5" }, ''));  
			el.appendChild(makeSVGnode('rect', { 'class':'popup', rx:Device.elementPadding, ry:Device.elementPadding, width: this.width, height: this.height, stroke:'gray', 'stroke-width':'0.25', fill:'url(#PopupGradient)', 'pointer-events':'all' }, ''));  
			el.appendChild(makeSVGnode('rect', { 'class':'header', x:Device.elementPadding, y:Device.elementPadding, rx:Device.elementPadding, ry:Device.elementPadding, width: (this.width-(Device.elementPadding*2)), height:Device.elementPadding*4, style: 'fill:'+nbackcolor }, ''));
			el.appendChild(makeSVGnode('text', { id: "name", x:Device.elementPadding*2, y:Device.elementPadding*4, 'text-anchor':'start' }, this.name));
			el.appendChild(makeSVGnode('text', { id: "bigtext", x: (this.width-(Device.elementPadding*2)), y: Device.elementPadding*4, 'text-anchor':'end', 'font-weight':'bold' }, this.data));

			var iOffset = ((sDirection == 'right') ? Device.elementPadding : ((this.image2 == '') ? this.width-Device.elementPadding-Device.iconSize : this.width-(Device.elementPadding*2)-(Device.iconSize*2)));
			var gImageGroup = makeSVGnode('g', { id: "imagegroup", transform:'translate(' + iOffset + ',' + Device.elementPadding*6 + ')' }, '');
			el.appendChild(gImageGroup);
			gImageGroup.appendChild(makeSVGnode('image',{id: "image", 'xlink:href': this.image, width:Device.iconSize, height:Device.iconSize, opacity: this.image_opacity, onclick:(this.onClick.length != 0) ? this.onClick : '', onmouseover:(this.onClick.length != 0) ? "cursorhand()" : '',  onmouseout:(this.onClick.length != 0) ? "cursordefault()" : '', 'pointer-events':'all'}, '', this.imagetext));
			if (this.image2 != '') {
				gImageGroup.appendChild(makeSVGnode('image',{id: "image2", x:Device.iconSize+Device.elementPadding, 'xlink:href': this.image2, width:Device.iconSize, height:Device.iconSize, opacity: this.image2_opacity, onclick:(this.onClick2.length != 0) ? this.onClick2 : '', onmouseover:(this.onClick.length != 0) ? "cursorhand()" : '',  onmouseout:(this.onClick.length != 0) ? "cursordefault()" : '', 'pointer-events':'all'}, '', this.imagetext));
			}
			iOffset = ((sDirection == 'right') ? ((this.image2 == '') ? Device.iconSize + (Device.elementPadding*2) : (Device.iconSize*2 + Device.elementPadding*3)) : Device.elementPadding*2);
			var gStatusGroup = makeSVGnode('g', { id: "statusgroup", transform:'translate(' + iOffset + ',' + Device.elementPadding*6 + ')' }, '');
			el.appendChild(gStatusGroup);
			if (this.haveDimmer == true) {
				gStatusGroup.appendChild(makeSVGnode('text', {id: "status", x:0, y:Device.elementPadding*2, 'font-weight':'bold', 'font-size':'90%' }, this.status));
				gStatusGroup.appendChild(makeSVGnode('rect', {id: "sliderback", 'class': "SliderBack", x:0, y:Device.elementPadding*3, width:Device.elementPadding*35, height: Device.elementPadding*2, rx:Device.elementPadding, ry:Device.elementPadding, fill:'url(#SliderImage)', stroke:'black', 'stroke-width':'0.5', 'pointer-events':'all'}, '', 'Adjust level'));
				gStatusGroup.appendChild(makeSVGnode('rect', {id: "slider", 'class': "Slider", x:0, y:Device.elementPadding*3, width:(((Device.elementPadding*35)/this.levelMax)*this.level)+(Device.elementPadding*2), height: Device.elementPadding*2, rx:Device.elementPadding, ry:Device.elementPadding, fill:'url(#SliderGradient)', stroke:'black', 'stroke-width':'0.5', 'pointer-events':'all'}, '', 'Adjust level'));
				gStatusGroup.appendChild(makeSVGnode('image',{id: "sliderhandle", 'class': "SliderHandle", x:((Device.elementPadding*35)/this.levelMax)*this.level, y:Device.elementPadding*2, xmax:Device.elementPadding*35, level:this.level, maxlevel:this.levelMax, devindex:this.index, 'xlink:href': 'images/handle.png', width: Device.elementPadding*4, height: Device.elementPadding*4, 'pointer-events':'all', onmouseover:"cursorhand()",  onmouseout:"cursordefault()"}, '', 'Slide to adjust level'));
			} else {
				gStatusGroup.appendChild(makeSVGmultiline({id: "status", x:0, y:Device.elementPadding*3, 'font-weight':'bold', 'font-size':'90%' }, this.status, '', Device.elementPadding*41, Device.elementPadding*2, Device.elementPadding*3 ));
			}
			var gText = makeSVGnode('text', {id: "lastseen", x:0, y:Device.elementPadding*7.5, 'font-size':'80%' }, '');
			gStatusGroup.appendChild(gText);
			gText.appendChild(makeSVGnode('tspan', { id: "lastlabel", 'font-size':'80%', 'font-style':'italic' }, 'Last Seen: ' ));
			gText.appendChild(makeSVGnode('tspan', { id: "lastupdate", 'font-size':'80%' }, ' '+this.lastupdate ));
			gStatusGroup.appendChild(makeSVGnode('image', { id: "favorite", x:(this.image2 == '') ? (this.width-65) : (this.width-100), y:Device.elementPadding*5, 'xlink:href': (this.favorite == 1) ? 'images/favorite.png' : 'images/nofavorite.png', onclick:(this.favorite == 1) ? "Device.MakeFavorite(" + this.index + ",0);" : "Device.MakeFavorite(" + this.index + ",1);", width:'16', height:'16', onmouseover:"cursorhand()",  onmouseout:"cursordefault()", 'pointer-events':'all' }, '', 'Toggle dashboard display' ));
		}
		else {  // this is not used but is included to show that the code could draw other than SVG
			el = makeSVGnode('div', { 'class': 'span4 DeviceDetails', id: this.uniquename+'_Detail', style: 'display:' + showme + '; position:relative; '}, '');
			var table = makeSVGnode('table', { 'id': 'itemtablesmall', border:'0', cellspacing: '0', cellpadding: '0' }, '');
			el.appendChild(table);
			var tbody = makeSVGnode('tbody', { }, '');
			table.appendChild(tbody);
			var tr = makeSVGnode('tr', { }, '');
			tbody.appendChild(tr);
			tr.appendChild(makeSVGnode('td', {id: "name", style: "background-color: rgb(164,177,238);" }, this.name));
			tr.appendChild(makeSVGnode('td', {id: "bigtext" }, this.data));
			tr.appendChild(makeSVGnode('img',{id: "image",src: this.image, width:Device.iconSize, height:Device.iconSize }, ''));
			tr.appendChild(makeSVGnode('td', {id: "status" }, this.status));
			tr.appendChild(makeSVGnode('span', {id: "lastseen", 'font-size':'80%', 'font-style':'italic' }, 'Last Seen: '));
			tr.appendChild(makeSVGnode('td', {id: "lastupdate" }, this.lastupdate));
		}
		
		if (existing != undefined) {
			existing.parentNode.replaceChild(el, existing);
		} else {
			parent.appendChild(el);
		}

		return el;
    }
    this.drawButtons = function() {
        return;
    }
    this.htmlMinimum = function(parent) {
		var mainEl;
		var mainEl = document.getElementById(this.uniquename);
		if (mainEl == undefined) {
			if (this.moveable == true) {
				mainEl = makeSVGnode('g', {  id:this.uniquename, transform:'translate(' + this.xoffset + ',' + this.yoffset + ')', idx:this.index, xoffset:this.xoffset, yoffset:this.yoffset, devscenetype:this.devSceneType }, '');
			} else {
				mainEl = makeSVGnode('g', {  id:this.uniquename, transform:'translate(' + this.xoffset + ',' + this.yoffset + ')' }, '');
			}
			this.drawIcon(mainEl);
			($("#DeviceIcons")[0] == undefined) ? parent.appendChild(mainEl) : $("#DeviceIcons")[0].appendChild(mainEl);

			if (this.moveable == true) {
				mainEl = makeSVGnode('g', {  id:this.uniquename, transform:'translate(' + this.xoffset + ',' + this.yoffset + ')', idx:this.index, xoffset:this.xoffset, yoffset:this.yoffset }, '');
			} else {
				mainEl = makeSVGnode('g', {  id:this.uniquename, transform:'translate(' + this.xoffset + ',' + this.yoffset + ')' }, '');
			}
			this.drawDetails(mainEl, false);
			($("#DeviceDetails")[0] == undefined) ? parent.appendChild(mainEl) : $("#DeviceDetails")[0].appendChild(mainEl);
		}
		else {
			this.drawIcon(mainEl);
			this.drawDetails(mainEl, false);
		}
		
		if (this.haveDimmer == true) {
			var oSlider = new Slider();
		}
			
		return mainEl;
    }
    this.htmlMedium = function() {
        return this.drawDetails();
    }
    this.htmlMaximum = function() {
        return this.drawDetails() + this.drawButtons();
    }
    this.htmlMobile = function() {
        return this.drawDetails();
    }
}
Device.count = 0;
Device.notPositioned = 0;
Device.useSVGtags = false;
Device.backFunction = 'DoNothing';
Device.switchFunction = 'DoNothing';
Device.contentTag = '';
Device.xImageSize = 1280;
Device.yImageSize = 720;
Device.iconSize = 32;
Device.elementPadding = 5;
Device.initialise = function() {
	Device.count = 0;
	Device.notPositioned = 0;
	if (Device.useSVGtags == true) {
		// clean up existing data if it exists
		$("#DeviceData").empty();
		$("#DeviceDetails").empty();
		$("#DeviceIcons").empty();

		var cont = document.getElementsByTagName('svg')[0];
		if (cont != undefined) {
			var devCont;
			if ($("#DeviceContainer")[0] == undefined) {
				devCont = makeSVGnode('g', { id: 'DeviceContainer'}, '');
				cont.appendChild(devCont);
				var defs = makeSVGnode('defs', { id: 'PopupDefs'}, '');
				cont.appendChild(defs);
				var linGrad = makeSVGnode('linearGradient', { id: 'PopupGradient', x1:"0%", y1:"0%", x2:"100%", y2:"100%"}, '');
				defs.appendChild(linGrad);
				linGrad.appendChild(makeSVGnode('stop', { offset:"25%", style:"stop-color:rgb(255,255,255);stop-opacity:1"}, ''));
				linGrad.appendChild(makeSVGnode('stop', { offset:"100%", style:"stop-color:rgb(225,225,225);stop-opacity:1"}, ''));
				linGrad = makeSVGnode('linearGradient', { id: 'SliderGradient', x1:"0%", y1:"0%", x2:"0%", y2:"100%"}, '');
				defs.appendChild(linGrad);
				linGrad.appendChild(makeSVGnode('stop', { offset:"0%", style:"stop-color:#11AAFD;stop-opacity:1"}, ''));
				linGrad.appendChild(makeSVGnode('stop', { offset:"100%", style:"stop-color:#0199E0;stop-opacity:1"}, ''));
				var imgPattern = makeSVGnode('pattern', { id: 'SliderImage', width:Device.elementPadding*2, height: Device.elementPadding*2, patternUnits:"userSpaceOnUse"}, '');
				defs.appendChild(imgPattern);
				imgPattern.appendChild(makeSVGnode('image', {'xlink:href':"css/images/bg-track.png", width:Device.elementPadding*2, height: Device.elementPadding*2}, ''));
			}
			if ($("#DeviceData")[0] == undefined) {
				devCont.appendChild(makeSVGnode('g', { id: 'DeviceData'}, ''));
			}
			if ($("#DeviceIcons")[0] == undefined) {
				devCont.appendChild(makeSVGnode('g', { id: 'DeviceIcons'}, ''));
			}
			if ($("#DeviceDetails")[0] == undefined) {
				devCont.appendChild(makeSVGnode('g', { id: 'DeviceDetails'}, ''));
			}
		}
	}
}
Device.create = function (item) {
	var dev;
	var type = '';

	// if we got a string instead of an object then convert it
	if (typeof item == 'string') {
		item = JSON.parse(item);
	}
	
	// Anomalies in device pattern (Scenes & Dusk sensors say they are  lights(???)
	if (item.Type == 'Scene') {
		type = 'scene';
	} else if (item.Type == 'Group') {
		type = 'group';
	} else if ((typeof item.SwitchType != 'undefined') && (item.SwitchType == 'Dusk Sensor')) { 
		item.TypeImg = item.SwitchType;
	} else {
		type = item.TypeImg.toLowerCase();
		if ((item.CustomImage != 0) && (typeof item.Image != 'undefined')) {
			type = item.Image.toLowerCase();
		}
	}

	switch (type) {
		case "baro":
			dev = new Baro(item);
			break;
		case "blinds":
		case "blinds inverted":
		case "blinds percentage":
			dev = new Blinds(item);
			break;
		case "contact":
			dev = new Contact(item);
			break;
		case "counter":
			dev = new Counter(item);
			break;
		case "current":
			dev = new Current(item);
			break;
		case "dimmer":
			dev = new Dimmer(item);
			break;
		case "door":
			dev = new Door(item);
			break;
		case "doorbell":
			dev = new Doorbell(item);
			break;
		case "dusk sensor":
			dev = new DuskSensor(item);
			break;
		case "fan":
			dev = new BinarySwitch(item);
			break;
		case "humidity":
			dev = new Humidity(item);
			break;
		case "lightbulb":
			dev = new Lightbulb(item);
			break;
		case "lux":
			dev = new Sensor(item);
			break;
		case "motion":
			dev = new Motion(item);
			break;
		case "group":
			dev = new Group(item);
			break;
		case "hardware":
			dev = new Hardware(item);
			break;
		case "push":
			dev = new Pushon(item);
			break;
		case "pushoff":
			dev = new Pushoff(item);
			break;
		case "override":
		case "override_mini":
			dev = new SetPoint(item);
			break;
		case "radiation":
			dev = new Radiation(item);
			break;
		case "rain":
			dev = new Rain(item);
			break;
		case "scene":
			dev = new Scene(item);
			break;
		case "siren":
			dev = new Siren(item);
			break;
		case "smoke":
			dev = new Smoke(item);
			break;
		case "temp":
		case "temperature":
			dev = new Temperature(item);
			break;
		case "visibility":
			dev = new Visibility(item);
			break;
		case "wind":
			dev = new Wind(item);
			break;
		default:
			if (typeof item.SwitchType != 'undefined') {
				dev = new Switch(item);
			} else {
				dev = new Sensor(item);
			}
	}

	return dev;
}
Device.scale = function (attr) {
	if (typeof $("#DeviceContainer")[0] != 'undefined') {
		$("#DeviceContainer")[0].setAttribute("transform", attr);
	}
	return;
}
Device.popup = function (target) {
	$('.DeviceDetails').css('display','none');   // hide all popups 
	
	// try to check if the popup needs to be flipped, if this can't be done just display it
	var oTarget = document.getElementById(target+"_Detail");
	var oTemp = oTarget.parentNode;
	var oTransform = new Transform();
	while (oTemp.nodeName.toLowerCase() != 'svg') {
		var oNew = new Transform(oTemp);
		oTransform.Add(oNew);
		oTemp = oTemp.parentNode;
	}
	oTarget.setAttribute('style', 'display:inline;');
	
	var imageWidth = (oTransform.scale == 0) ? Device.xImageSize : Device.xImageSize / oTransform.scale;
	var requiredWidth = oTransform.xOffset + parseInt(oTarget.getAttribute('width'));
	var sDir = (imageWidth < requiredWidth) ? 'left' : 'right';
	if (sDir != oTarget.getAttribute('direction')) {
		oTarget.setAttribute('direction', sDir);
	}
	var oData = document.getElementById(target+"_Data");
	var sData = oData.getAttribute('item');
	var oDevice = new Device.create(sData);
	oDevice.htmlMinimum(oTarget.parentNode);
}
Device.MakeFavorite = function (id, isfavorite) {
	if (window.my_config.userrights!=2) {
        HideNotify();
		ShowNotify($.i18n('You do not have permission to do that!'), 2500, true);
		return;
	}
	clearInterval($.myglobals.refreshTimer);
	$.ajax({
		url: "json.htm?type=command&param=makefavorite&idx=" + id + "&isfavorite=" + isfavorite, 
		async: false, 
		dataType: 'json',
		success: function(data) {
			window.myglobals.LastUpdate = 0;
			eval(Device.switchFunction + "();");
		}
	});
}

function Sensor (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = "images/" + item.TypeImg + "48.png";
		this.onClick = "Show" + this.type.replace(/\s/g, '') + "Log('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
		this.imagetext = "Show graph";
	}
}
Sensor.inheritsFrom ( Device );

function BinarySensor (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
	}
}
BinarySensor.inheritsFrom ( Sensor );

function SecuritySensor (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = (this.status == "On") ? "images/" + item.TypeImg + "48-on.png" : "images/" + item.TypeImg + "48-off.png";
	}
}
SecuritySensor.inheritsFrom ( BinarySensor );

function TemperatureSensor (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = "images/temp48.png";
		this.status = $.i18n('Temp') + ': ' + this.data;
		this.onClick = "ShowTempLog('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
	}
}
TemperatureSensor.inheritsFrom ( Sensor );

function WeatherSensor (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
	}
}
WeatherSensor.inheritsFrom ( Sensor );

function Switch (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.imagetext = "Activate switch";
		this.controlable = true;
		this.onClick = "SwitchLight(" + this.index + ",'" + ((this.status == "Off") ? "On" : "Off") + "'," + Device.switchFunction + "," + this.protected + ");";
		if (item.CustomImage != 0) {
			this.image = (this.status == "On") ? "images/" + item.Image + "48_On.png" : "images/" + item.Image + "48_Off.png";
		} else {
			this.image = (this.status == "On") ? "images/" + item.TypeImg + "48_On.png" : "images/" + item.TypeImg + "48_Off.png";
		}
	}
}
Switch.inheritsFrom ( Sensor );

function BinarySwitch (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.onClick = "SwitchLight(" + this.index + ",'" + ((this.status == "On") ? "Off" : "On") + "'," + Device.switchFunction + "," + this.protected + ");";
		this.data = '';
	}
}
BinarySwitch.inheritsFrom ( Switch );


function Baro (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		if (this.name == 'Baro') this.name = 'Barometer';
		this.image = "images/baro48.png";
		this.onClick = "ShowBaroLog('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "');";
		if (typeof item.Barometer != 'undefined') {
			this.data = item.Barometer + ' hPa';
			if (typeof item.ForecastStr != 'undefined') {
				this.status = item.Barometer + ' hPa, ' + $.i18n('Prediction') + ': ' + $.i18n(item.ForecastStr);
			}
			else {
				this.status = item.Barometer + ' hPa';
			}
			if (typeof item.Altitude != 'undefined') {
				this.status += ', Altitude: ' + item.Altitude + ' meter';
			}
		}
	}
}
Baro.inheritsFrom ( WeatherSensor );

function Blinds (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.data = '';
		this.haveDimmer = (this.type.toLowerCase() == "blinds percentage") ? true : false;
		if (item.Status == 'Closed') {
			this.image = 'images/blindsopen48.png';
			this.onClick = 'SwitchLight(' + this.index + ",'" + ((item.SwitchType == "Blinds Inverted") ? 'On' : 'Off') + "'," + Device.switchFunction + ',' + this.protected +');';
			this.image2 = 'images/blinds48sel.png';
			this.onClick2 = 'SwitchLight(' + this.index + ",'" + ((item.SwitchType == "Blinds Inverted") ? 'Off' : 'On') + "'," + Device.switchFunction + ',' + this.protected +');';
		}
		else {
			this.image = 'images/blindsopen48sel.png';
			this.onClick = 'SwitchLight(' + this.index + ",'" + ((item.SwitchType == "Blinds Inverted") ? 'On' : 'Off') + "'," + Device.switchFunction + ',' + this.protected +');';
			this.image2 = 'images/blinds48.png';
			this.onClick2 = 'SwitchLight(' + this.index + ",'" + ((item.SwitchType == "Blinds Inverted") ? 'Off' : 'On') + "'," + Device.switchFunction + ',' + this.protected +');';
		}
	}
}
Blinds.inheritsFrom ( Switch );

function Counter (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = "images/counter.png";
		this.onClick = "ShowCounterLog('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
		if (typeof item.CounterToday != 'undefined') {
			this.status += ' ' + $.i18n("Today") + ': ' + item.CounterToday;
		}
		if (typeof item.CounterDeliv != 'undefined') {
			if (item.CounterDeliv!=0) {
				if (item.UsageDeliv.charAt(0) != 0) {
					this.status += '-' + item.UsageDeliv;
				}
				this.status += ', ' + $.i18n("Return") + ': ' + item.CounterDelivToday;
			}
		}
	}
}
Counter.inheritsFrom ( Sensor );

function Contact (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = (this.status == "Closed") ? "images/contact48.png" : this.image = "images/contact48_open.png";
		this.data = '';
		this.onClick = "ShowLightLog('" + this.index + "','" + this.name + "','#" + Device.contentTag + "','" + Device.backFunction + "');";
	}
}
Contact.inheritsFrom ( BinarySensor );

function Current (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		switch (this.type) {
			case "Energy":
				this.onClick = "ShowCounterLogSpline('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
				break;
			case "Usage":
				this.onClick = "ShowUsageLog('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
				break;
			default:
				this.onClick = "ShowCurrentLog('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
		}
		this.status = '';
		if (typeof item.Usage != 'undefined') {
			this.status = (item.Usage != this.data) ? item.Usage : '';
		}
		if (typeof item.CounterToday != 'undefined') {
			this.status += ' ' + $.i18n("Today") + ': ' + item.CounterToday;
		}
		if (typeof item.CounterDeliv != 'undefined') {
			if (item.CounterDeliv!=0) {
				if (item.UsageDeliv.charAt(0) != 0) {
					this.status += '-' + item.UsageDeliv;
				}
				this.status += ', ' + $.i18n("Return") + ': ' + item.CounterDelivToday;
			}
		}
	}
}
Current.inheritsFrom ( Sensor );

function Dimmer (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.haveDimmer = true;
		this.image = (this.status == "Off") ? "images/dimmer48-off.png" : this.image = "images/dimmer48-on.png";
		this.data = '';
	}
}
Dimmer.inheritsFrom ( Switch );

function Door (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = (this.status == "Closed") ? "images/" + item.TypeImg + "48.png" : this.image = "images/" + item.TypeImg + "48open.png";
		this.data = '';
	}
}
Door.inheritsFrom ( BinarySwitch );

function Doorbell (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = "images/doorbell48.png";
		this.data = '';
	}
}
Doorbell.inheritsFrom ( BinarySwitch );

function DuskSensor (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = (item.Status == 'On') ? "images/uvdark.png" : this.image = "images/uvsunny.png";
		this.onClick = "ShowLightLog('" + this.index + "','" + this.name + "','#" + Device.contentTag + "','" + Device.backFunction + "');";
		this.data = '';
	}
}
DuskSensor.inheritsFrom ( BinarySensor );

function Group (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = 'images/push48.png';
		this.onClick = 'SwitchScene(' + this.index + ", 'On', undefined, " + this.protected + ');';
		this.image2 = 'images/pushoff48.png';
		this.onClick2 = 'SwitchScene(' + this.index + ", 'Off', undefined, " + this.protected + ');';
		(this.status == 'Off') ? this.image2_opacity = 0.5 : this.image_opacity = 0.5;
		this.data = '';
	}
}
Group.inheritsFrom ( Sensor );

function Hardware (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.onClick = "Show" + this.subtype + "Log('#" + Device.contentTag + "','" + Device.backFunction + "','" + this.index + "','" + this.name + "', '" + this.switchTypeVal + "');";
		if (item.CustomImage == 0) 
			switch (item.SubType.toLowerCase()) {
				case "percentage":
					this.image = "images/Percentage48.png";
					break;
		}
	}
}
Hardware.inheritsFrom ( Sensor );

function Humidity (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = "images/moisture48.png";
		if (typeof item.Humidity != 'undefined') {
			this.data = item.Humidity + '%';
			this.status = $.i18n('Humidity') + ': ' + item.Humidity + '%';
			if (typeof item.HumidityStatus != 'undefined') {
				this.status += ', ' + item.HumidityStatus;
			}
			if (typeof item.DewPoint != 'undefined') {
				this.status += ', ' + $.i18n("Dew Point") + ": " + item.DewPoint + '\u00B0' + $.myglobals.tempsign;
			}
		}
	}
}
Humidity.inheritsFrom ( WeatherSensor );

function Lightbulb (item) {
	if (arguments.length != 0) {
		item.TypeImg = "Light";
		this.parent.constructor (item);
	}
}
Lightbulb.inheritsFrom ( BinarySwitch );

function Motion (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = (this.status == "On") ? "images/" + item.TypeImg + "48-on.png" : "images/" + item.TypeImg + "48-off.png";
		this.onClick = "ShowLightLog('" + this.index + "','" + this.name + "','#" + Device.contentTag + "','" + Device.backFunction + "');";
		this.data = '';
	}
}
Motion.inheritsFrom ( SecuritySensor );

function Pushon (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = (this.status == "On") ? "images/pushon48.png" : "images/push48.png";
	}
}
Pushon.inheritsFrom ( BinarySwitch );

function Pushoff (item) {
	if (arguments.length != 0) {
		item.Status = 'Off';
		this.parent.constructor (item);
		this.image = "images/pushoff48.png";
	}
}
Pushoff.inheritsFrom ( BinarySwitch );

function Radiation (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.onClick = "ShowGeneralGraph('#" + Device.contentTag + "','" + Device.backFunction + "'," + this.index + ",'" + this.name + "', '" + this.switchTypeVal + "', 'Radiation');";
	}
}
Radiation.inheritsFrom ( WeatherSensor );

function Rain (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		if (typeof item.Rain != 'undefined') {
			this.status = item.Rain + ' mm';
			this.data = this.status;
			if (typeof item.RainRate != 'undefined') {
				if (item.RainRate != 0) {
					this.status += ', Rate: ' + item.RainRate + ' mm/h';
				}
			}
		}
	}
}
Rain.inheritsFrom ( WeatherSensor );

function Scene (item) {
	if (arguments.length != 0) {
		item.Status = 'Off';
		this.parent.constructor (item);
		this.onClick = 'SwitchScene(' + this.index + ", 'On','" + Device.backFunction + "', " + this.protected + ');';
		this.data = '';
	}
}
Scene.inheritsFrom ( Pushon );

function SetPoint (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = "images/override.png";
		this.data += '\u00B0' + $.myglobals.tempsign;
		this.status += '\u00B0' + $.myglobals.tempsign;
	}
}
SetPoint.inheritsFrom ( TemperatureSensor );

function Siren (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = ((item.Status == 'On')|| (item.Status == 'Chime')|| (item.Status == 'Group On')|| (item.Status == 'All On')) ? "images/siren-on.png" : this.image = "images/siren-off.png";
		this.onClick = '';
	}
}
Siren.inheritsFrom ( BinarySensor );

function Smoke (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = ((item.Status == "Panic")|| (item.Status == "On")) ? "images/smoke48on.png" : this.image = "images/smoke48off.png";
		this.onClick = "ShowLightLog('" + this.index + "','" + this.name + "','#" + Device.contentTag + "','" + Device.backFunction + "');";
		this.data = '';
	}
}
Smoke.inheritsFrom ( BinarySensor );

function Temperature (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		if (typeof item.Temp != 'undefined') {
			this.image = "images/" + GetTemp48Item(item.Temp);
			this.data  = item.Temp + '\u00B0' + $.myglobals.tempsign;
		}
		if (typeof item.Chill != 'undefined') {
			this.data += ',' + $.i18n('Chill') +': ' + item.Chill + '\u00B0' + $.myglobals.tempsign;
		}
	}
}
Temperature.inheritsFrom ( TemperatureSensor );

function Visibility (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.onClick = "ShowGeneralGraph('#" + Device.contentTag + "','" + Device.backFunction + "'," + this.index + ",'" + this.name + "', '" + this.switchTypeVal + "', '" + this.subtype + "');";
	}
}
Visibility.inheritsFrom ( WeatherSensor );

function Wind (item) {
	if (arguments.length != 0) {
		this.parent.constructor (item);
		this.image = "images/wind48.png";
		if (typeof item.DirectionStr != 'undefined') {
			this.image = "images/Wind" + item.DirectionStr + ".png";
			this.status = item.DirectionStr;
			this.data = item.DirectionStr;
			if (typeof item.Direction != 'undefined') {
				this.status = item.Direction + ' ' + item.DirectionStr;
			}
		}
		if (typeof item.Speed != 'undefined') {
			this.status += ', ' + item.Speed + ' ' + $.myglobals.windsign;
			this.data += ' / ' + item.Speed + ' ' + $.myglobals.windsign;
		}
		if (typeof item.Gust != 'undefined') {
			this.status += ', ' + $.i18n('Gust') + ': ' + item.Gust + ' ' + $.myglobals.windsign;
		}
	}
}
Wind.inheritsFrom ( WeatherSensor );
