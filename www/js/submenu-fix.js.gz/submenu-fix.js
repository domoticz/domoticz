/*
* This fixes the problem that the 'More Options' closes on click.
* This is a problem for touchscreen devices because it is nearly impossible to open the 'More Options' menu when it keeps closing onclick.
*/
$(document).ready(function() {
	$('a#cMoreOptions').click(function(e) {
		e.preventDefault();
		e.stopPropagation();
		$('a#cMoreOptions').trigger('mouseenter');
	});
} );